# import stripe
# from flask import Blueprint, request, jsonify
# from flask_jwt_extended import jwt_required, get_jwt_identity
# from extensions import db
# from models.order import Order
# from config import Config
# from middleware.role import role_required

# payment_bp = Blueprint("payment", __name__)
# stripe.api_key = Config.STRIPE_SECRET_KEY


# @payment_bp.route("/payments", methods=["POST"])
# @jwt_required()
# def create_payment():
#     data = request.get_json()
#     order = Order.query.get_or_404(data["order_id"])
#     order.payment_method = data.get("payment_method")
#     db.session.commit()
#     return jsonify({"message": "Payment initiated", "order_id": order.id}), 201


# @payment_bp.route("/payments/<int:order_id>", methods=["GET"])
# @jwt_required()
# def get_payment(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "order_id": order.id,
#         "payment_method": order.payment_method,
#         "payment_status": order.payment_status,
#         "total": float(order.total)
#     }), 200


# @payment_bp.route("/payments/<int:order_id>/create-link", methods=["POST"])
# @jwt_required()
# def create_payment_link(order_id):
#     order = Order.query.get_or_404(order_id)
#     try:
#         session = stripe.checkout.Session.create(
#             payment_method_types=["card"],
#             line_items=[{
#                 "price_data": {
#                     "currency": order.currency.lower() if order.currency else "inr",
#                     "product_data": {"name": f"Order #{order.order_number}"},
#                     "unit_amount": int(float(order.total) * 100)
#                 },
#                 "quantity": 1
#             }],
#             mode="payment",
#             success_url=f"{request.host_url}payments/{order_id}/verify?session_id={{CHECKOUT_SESSION_ID}}",
#             cancel_url=f"{request.host_url}orders/{order_id}"
#         )
#         order.stripe_session_id = session.id
#         db.session.commit()
#         return jsonify({"payment_url": session.url, "session_id": session.id}), 200
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500


# @payment_bp.route("/payments/<int:order_id>/verify", methods=["POST"])
# @jwt_required()
# def verify_payment(order_id):
#     order = Order.query.get_or_404(order_id)
#     data = request.get_json() or {}
#     session_id = data.get("session_id") or request.args.get("session_id")
#     try:
#         session = stripe.checkout.Session.retrieve(session_id)
#         if session.payment_status == "paid":
#             order.payment_status = "PAID"
#             db.session.commit()
#             return jsonify({"message": "Payment verified", "status": "PAID"}), 200
#         return jsonify({"message": "Payment not completed", "status": session.payment_status}), 400
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500


# @payment_bp.route("/payments/<int:order_id>/mark-paid", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "SALES_AGENT"])
# def mark_paid(order_id):
#     order = Order.query.get_or_404(order_id)
#     data = request.get_json() or {}
#     order.payment_status = "PAID"
#     order.payment_method = data.get("payment_method", order.payment_method)
#     db.session.commit()
#     return jsonify({"message": "Order marked as paid", "order": order.to_dict()}), 200


# @payment_bp.route("/payments/report", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def payment_report():
#     from sqlalchemy import func
#     paid = Order.query.filter_by(payment_status="PAID").all()
#     pending = Order.query.filter_by(payment_status="PENDING").count()
#     total_collected = sum(float(o.total) for o in paid)
#     by_method = db.session.query(
#         Order.payment_method, func.count(Order.id), func.sum(Order.total)
#     ).filter_by(payment_status="PAID").group_by(Order.payment_method).all()
#     return jsonify({
#         "total_paid_orders": len(paid),
#         "total_collected": total_collected,
#         "pending_orders": pending,
#         "by_method": [
#             {"method": r[0], "count": r[1], "amount": float(r[2] or 0)}
#             for r in by_method
#         ]
#     }), 200


# # ─── INVOICES ────────────────────────────────────────────────────────────────

# @payment_bp.route("/invoices/<int:order_id>", methods=["GET"])
# @jwt_required()
# def get_invoice(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "invoice_number": f"INV-{order.order_number}",
#         "order": order.to_dict(),
#         "issued_at": order.created_at.isoformat()
#     }), 200


# @payment_bp.route("/invoices/<int:order_id>/download", methods=["POST"])
# @jwt_required()
# def download_invoice(order_id):
#     # Placeholder: generate PDF invoice and return URL
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "message": "Invoice download ready",
#         "order_id": order_id,
#         "invoice_url": f"/invoices/{order_id}/file"
#     }), 200


# @payment_bp.route("/invoices/<int:order_id>/share-whatsapp", methods=["POST"])
# @jwt_required()
# def share_invoice_whatsapp(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "message": "Invoice shared via WhatsApp",
#         "order_id": order_id
#     }), 200






# import requests
# from flask import Blueprint, request, jsonify
# from flask_jwt_extended import jwt_required
# from extensions import db
# from models.order import Order
# from config import Config
# from middleware.role import role_required

# payment_bp = Blueprint("payment", __name__)


# print("========== PAYMENT ROUTES LOADED ==========")


# @payment_bp.route("/payments", methods=["POST"])
# @jwt_required()
# def create_payment():
#     data = request.get_json()
#     order = Order.query.get_or_404(data["order_id"])
#     order.payment_method = data.get("payment_method")
#     db.session.commit()
#     return jsonify({"message": "Payment initiated", "order_id": order.id}), 201


# @payment_bp.route("/payments/<int:order_id>", methods=["GET"])
# @jwt_required()
# def get_payment(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "order_id": order.id,
#         "payment_method": order.payment_method,
#         "payment_status": order.payment_status,
#         "total": float(order.total)
#     }), 200


# @payment_bp.route("/payments/<int:order_id>/create-link", methods=["POST"])
# @jwt_required()
# def create_payment_link(order_id):

#     order = Order.query.get_or_404(order_id)

#     headers = {
#         "Authorization": f"Bearer {Config.TAP_SECRET_KEY}",
#         "Content-Type": "application/json"
#     }

#     payload = {
#         "amount": float(order.total),
#         "currency": "KWD",

#         "threeDSecure": True,

#         "save_card": False,

#         "description": f"Order #{order.order_number}",

#         "customer": {
#             "first_name": order.customer.first_name,
#             "last_name": order.customer.last_name,
#             "email": order.customer.email,
#             "phone": {
#                 "country_code": "965",
#                 "number": order.customer.phone_no
#             }
#         },

#         "source": {
#             "id": "src_kw.knet"
#         },

#         "redirect": {
#             "url": f"http://localhost:5000/payments/{order.id}/verify"
#         }
#     }

#     response = requests.post(
#         "https://api.tap.company/v2/charges",
#         headers=headers,
#         json=payload
#     )

#     return jsonify(response.json())

# @payment_bp.route("/payments/<int:order_id>/verify")
# def verify_payment(order_id):

#     order = Order.query.get_or_404(order_id)

#     tap_id = request.args.get("tap_id")

#     if not tap_id:
#         return jsonify({"error": "Missing tap_id"}), 400

#     headers = {
#         "Authorization": f"Bearer {Config.TAP_SECRET_KEY}"
#     }

#     response = requests.get(
#         f"https://api.tap.company/v2/charges/{tap_id}",
#         headers=headers
#     )

#     data = response.json()

#     if data["status"] == "CAPTURED":
#         order.payment_status = "PAID"
#         order.payment_method = "KNET"

#         db.session.commit()

#         return jsonify({
#             "message": "Payment successful"
#         })

#     return jsonify({
#         "message": "Payment failed",
#         "status": data["status"]
#     }), 400



# @payment_bp.route("/payments/<int:order_id>/mark-paid", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "SALES_AGENT"])
# def mark_paid(order_id):
#     order = Order.query.get_or_404(order_id)
#     data = request.get_json() or {}
#     order.payment_status = "PAID"
#     order.payment_method = data.get("payment_method", order.payment_method)
#     db.session.commit()
#     return jsonify({"message": "Order marked as paid", "order": order.to_dict()}), 200


# @payment_bp.route("/payments/report", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def payment_report():
#     from sqlalchemy import func
#     paid = Order.query.filter_by(payment_status="PAID").all()
#     pending = Order.query.filter_by(payment_status="PENDING").count()
#     total_collected = sum(float(o.total) for o in paid)
#     by_method = db.session.query(
#         Order.payment_method, func.count(Order.id), func.sum(Order.total)
#     ).filter_by(payment_status="PAID").group_by(Order.payment_method).all()
#     return jsonify({
#         "total_paid_orders": len(paid),
#         "total_collected": total_collected,
#         "pending_orders": pending,
#         "by_method": [
#             {"method": r[0], "count": r[1], "amount": float(r[2] or 0)}
#             for r in by_method
#         ]
#     }), 200


# # ─── INVOICES ────────────────────────────────────────────────────────────────

# @payment_bp.route("/invoices/<int:order_id>", methods=["GET"])
# @jwt_required()
# def get_invoice(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "invoice_number": f"INV-{order.order_number}",
#         "order": order.to_dict(),
#         "issued_at": order.created_at.isoformat()
#     }), 200


# @payment_bp.route("/invoices/<int:order_id>/download", methods=["POST"])
# @jwt_required()
# def download_invoice(order_id):
#     # Placeholder: generate PDF invoice and return URL
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "message": "Invoice download ready",
#         "order_id": order_id,
#         "invoice_url": f"/invoices/{order_id}/file"
#     }), 200


# @payment_bp.route("/invoices/<int:order_id>/share-whatsapp", methods=["POST"])
# @jwt_required()
# def share_invoice_whatsapp(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "message": "Invoice shared via WhatsApp",
#         "order_id": order_id
#     }), 200


import stripe
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models.order import Order
from config import Config
from middleware.role import role_required

payment_bp = Blueprint("payment", __name__)
stripe.api_key = Config.STRIPE_SECRET_KEY


@payment_bp.route("/payments", methods=["POST"])
@jwt_required()
def create_payment():
    data = request.get_json()
    order = Order.query.get_or_404(data["order_id"])
    order.payment_method = data.get("payment_method")
    db.session.commit()
    return jsonify({"message": "Payment initiated", "order_id": order.id}), 201


@payment_bp.route("/payments/<int:order_id>", methods=["GET"])
@jwt_required()
def get_payment(order_id):
    order = Order.query.get_or_404(order_id)
    return jsonify({
        "order_id": order.id,
        "payment_method": order.payment_method,
        "payment_status": order.payment_status,
        "total": float(order.total)
    }), 200


@payment_bp.route("/payments/<int:order_id>/create-link", methods=["POST"])
@jwt_required()
def create_payment_link(order_id):
    order = Order.query.get_or_404(order_id)
    try:
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            line_items=[{
                "price_data": {
                    "currency": order.currency.lower() if order.currency else "inr",
                    "product_data": {"name": f"Order #{order.order_number}"},
                    "unit_amount": int(float(order.total) * 100)
                },
                "quantity": 1
            }],
            mode="payment",
            success_url=f"{request.host_url}payments/{order_id}/verify?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{request.host_url}orders/{order_id}"
        )
        order.stripe_session_id = session.id
        db.session.commit()
        return jsonify({"payment_url": session.url, "session_id": session.id}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@payment_bp.route("/payments/<int:order_id>/verify", methods=["POST"])
@jwt_required()
def verify_payment(order_id):
    order = Order.query.get_or_404(order_id)
    data = request.get_json() or {}
    session_id = data.get("session_id") or request.args.get("session_id")
    try:
        session = stripe.checkout.Session.retrieve(session_id)
        if session.payment_status == "paid":
            order.payment_status = "PAID"
            db.session.commit()
            return jsonify({"message": "Payment verified", "status": "PAID"}), 200
        return jsonify({"message": "Payment not completed", "status": session.payment_status}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@payment_bp.route("/payments/<int:order_id>/mark-paid", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "SALES_AGENT"])
def mark_paid(order_id):
    order = Order.query.get_or_404(order_id)
    data = request.get_json() or {}
    order.payment_status = "PAID"
    order.payment_method = data.get("payment_method", order.payment_method)
    db.session.commit()
    return jsonify({"message": "Order marked as paid", "order": order.to_dict()}), 200


@payment_bp.route("/payments/report", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def payment_report():
    from sqlalchemy import func
    paid = Order.query.filter_by(payment_status="PAID").all()
    pending = Order.query.filter_by(payment_status="PENDING").count()
    total_collected = sum(float(o.total) for o in paid)
    by_method = db.session.query(
        Order.payment_method, func.count(Order.id), func.sum(Order.total)
    ).filter_by(payment_status="PAID").group_by(Order.payment_method).all()
    return jsonify({
        "total_paid_orders": len(paid),
        "total_collected": total_collected,
        "pending_orders": pending,
        "by_method": [
            {"method": r[0], "count": r[1], "amount": float(r[2] or 0)}
            for r in by_method
        ]
    }), 200


# ─── INVOICES ────────────────────────────────────────────────────────────────

@payment_bp.route("/invoices/<int:order_id>", methods=["GET"])
@jwt_required()
def get_invoice(order_id):
    order = Order.query.get_or_404(order_id)
    return jsonify({
        "invoice_number": f"INV-{order.order_number}",
        "order": order.to_dict(),
        "issued_at": order.created_at.isoformat()
    }), 200


@payment_bp.route("/invoices/<int:order_id>/download", methods=["POST"])
@jwt_required()
def download_invoice(order_id):
    # Placeholder: generate PDF invoice and return URL
    order = Order.query.get_or_404(order_id)
    return jsonify({
        "message": "Invoice download ready",
        "order_id": order_id,
        "invoice_url": f"/invoices/{order_id}/file"
    }), 200


@payment_bp.route("/invoices/<int:order_id>/share-whatsapp", methods=["POST"])
@jwt_required()
def share_invoice_whatsapp(order_id):
    order = Order.query.get_or_404(order_id)
    return jsonify({
        "message": "Invoice shared via WhatsApp",
        "order_id": order_id
    }), 200