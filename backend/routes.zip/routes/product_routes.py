# from flask import Blueprint, request, jsonify
# from extensions import db
# from models.product import Product
# from models.order_item import OrderItem

# product_bp = Blueprint("product", __name__)


# # Create Product
# @product_bp.route("/products", methods=["POST"])
# def create_product():
#     try:
#         data = request.get_json()

#         if not data:
#             return jsonify({"error": "No input data provided"}), 400

#         product = Product(
#             name=data.get("name"),
#             category_id=data.get("category_id"),
#             price=data.get("price"),
#             original_price=data.get("original_price"),
#             stock=data.get("stock", 0),
#             unit=data.get("unit"),
#             image_url=data.get("image_url"),
#             description=data.get("description"),
#             ingredients=data.get("ingredients")
#         )

#         db.session.add(product)
#         db.session.commit()

#         return jsonify({
#             "message": "Product created successfully",
#             "product": product.to_dict()
#         }), 201

#     except Exception as e:
#         db.session.rollback()
#         print("ERROR:", str(e))
#         return jsonify({"error": str(e)}), 500



# # Get All Products
# # @product_bp.route("/products", methods=["GET"])
# # def get_products():

# #     products = Product.query.all()

# #     return jsonify([
# #         product.to_dict()
# #         for product in products
# #     ]), 200


# @product_bp.route("/products", methods=["GET"])
# def get_products():

#     currency = request.headers.get(
#         "X-Currency",
#         "INR"
#     )

#     products = Product.query.all()

#     return jsonify([
#         product.to_dict(currency)
#         for product in products
#     ]), 200




# # Get Single Product
# # @product_bp.route("/products/<int:id>", methods=["GET"])
# # def get_product(id):

# #     product = Product.query.get(id)

# #     if not product:
# #         return jsonify({
# #             "error": "Product not found"
# #         }), 404

# #     return jsonify(
# #         product.to_dict()
# #     ), 200


# @product_bp.route("/products/<int:id>", methods=["GET"])
# def get_product(id):

#     product = Product.query.get(id)

#     if not product:
#         return jsonify({
#             "error": "Product not found"
#         }), 404

#     currency = request.headers.get(
#         "X-Currency",
#         "INR"
#     )

#     return jsonify(
#         product.to_dict(currency)
#     ), 200

# # Update Product
# @product_bp.route("/products/<int:id>", methods=["PUT"])
# def update_product(id):

#     product = Product.query.get(id)

#     if not product:
#         return jsonify({
#             "error": "Product not found"
#         }), 404

#     data = request.get_json()

#     product.name = data.get("name", product.name)
#     product.description = data.get("description", product.description)
#     product.price = data.get("price", product.price)
#     product.stock = data.get("stock", product.stock)
#     product.image_url = data.get("image_url", product.image_url)
#     product.category_id = data.get("category_id", product.category_id)

#     db.session.commit()

#     return jsonify({
#         "message": "Product updated successfully",
#         "product": product.to_dict()
#     }), 200


# # # Delete Product
# # @product_bp.route("/products/<int:id>", methods=["DELETE"])
# # def delete_product(id):
# #     product = Product.query.get_or_404(id)

# #     order_item = OrderItem.query.filter_by(product_id=id).first()

# #     if order_item:
# #         return jsonify({
# #             "error": "Cannot delete product. It exists in customer orders."
# #         }), 400

# #     db.session.delete(product)
# #     db.session.commit()

# #     return jsonify({"message": "Deleted successfully"})



# @product_bp.route("/products/<int:id>", methods=["DELETE"])
# def delete_product(id):

#     try:
#         product = Product.query.get(id)

#         if not product:
#             return jsonify({
#                 "error": "Product not found"
#             }), 404

#         order_exists = OrderItem.query.filter_by(
#             product_id=id
#         ).first()

#         if order_exists:
#             return jsonify({
#                 "error": "Cannot delete product because it is used in orders"
#             }), 400

#         db.session.delete(product)
#         db.session.commit()

#         return jsonify({
#             "message": "Product deleted successfully"
#         }), 200

#     except Exception as e:
#         db.session.rollback()

#         return jsonify({
#             "error": str(e)
#         }), 500

# # ─── NEW: Additional product API routes ──────────────────────────────────────

# @product_bp.route("/products/category/<int:category_id>", methods=["GET"])
# def get_products_by_category(category_id):
#     products = Product.query.filter_by(category_id=category_id).all()
#     return jsonify({"products": [p.to_dict() for p in products]}), 200


# @product_bp.route("/products/<int:product_id>/link-category", methods=["POST"])
# def link_product_category(product_id):
#     data = request.get_json()
#     product = Product.query.get_or_404(product_id)
#     product.category_id = data["category_id"]
#     db.session.commit()
#     return jsonify({"message": "Category linked", "product": product.to_dict()}), 200


# @product_bp.route("/products/<int:product_id>/unlink-category/<int:category_id>", methods=["DELETE"])
# def unlink_product_category(product_id, category_id):
#     product = Product.query.get_or_404(product_id)
#     if product.category_id == category_id:
#         product.category_id = None
#         db.session.commit()
#     return jsonify({"message": "Category unlinked"}), 200


# @product_bp.route("/products/<int:product_id>/categories", methods=["GET"])
# def get_product_categories(product_id):
#     from models.category import Category
#     product = Product.query.get_or_404(product_id)
#     category = Category.query.get(product.category_id) if product.category_id else None
#     return jsonify({"categories": [category.to_dict()] if category else []}), 200


# @product_bp.route("/products/<int:product_id>/variants", methods=["GET"])
# def get_product_variants(product_id):
#     from models.variant import Variant
#     variants = Variant.query.filter_by(product_id=product_id).all()
#     return jsonify({"variants": [v.to_dict() for v in variants]}), 200



from flask import Blueprint, request, jsonify
from extensions import db
from models.product import Product
from models.wishlist import Wishlist;

product_bp = Blueprint("product", __name__)


# Create Product
@product_bp.route("/products", methods=["POST"])
def create_product():
    try:
        data = request.get_json()

        if not data:
            return jsonify({"error": "No input data provided"}), 400

        product = Product(
            name=data.get("name"),
            category_id=data.get("category_id"),
            price=data.get("price"),
            original_price=data.get("original_price"),
            stock=data.get("stock", 0),
            unit=data.get("unit"),
            image_url=data.get("image_url"),
            description=data.get("description"),
            ingredients=data.get("ingredients")
        )

        db.session.add(product)
        db.session.commit()

        return jsonify({
            "message": "Product created successfully",
            "product": product.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        print("ERROR:", str(e))
        return jsonify({"error": str(e)}), 500



# Get All Products
# @product_bp.route("/products", methods=["GET"])
# def get_products():

#     products = Product.query.all()

#     return jsonify([
#         product.to_dict()
#         for product in products
#     ]), 200


@product_bp.route("/products", methods=["GET"])
def get_products():

    currency = request.headers.get(
        "X-Currency",
        "INR"
    )

    is_admin = request.args.get("admin") == "true"

    if is_admin:
        # Admins see everything (Active + Inactive)
        query = Product.query
    else:
        # Users/Customers only see active products
        query = Product.query.filter_by(is_active=True)

    # ─── Optional filters (used by the chatbot's product search, and by the
    #     storefront search bar). Additive only — existing behaviour when no
    #     query params are supplied is unchanged. ─────────────────────────────

    search = request.args.get("search", "").strip()
    if search:
        like = f"%{search}%"
        query = query.filter(
            db.or_(
                Product.name.ilike(like),
                Product.description.ilike(like),
                Product.ingredients.ilike(like)
            )
        )

    category_id = request.args.get("category_id", type=int)
    if category_id:
        query = query.filter(Product.category_id == category_id)

    max_price = request.args.get("max_price", type=float)
    if max_price is not None:
        query = query.filter(Product.price <= max_price)

    min_price = request.args.get("min_price", type=float)
    if min_price is not None:
        query = query.filter(Product.price >= min_price)

    in_stock_only = request.args.get("in_stock") == "true"
    if in_stock_only:
        query = query.filter(Product.stock > 0)

    products = query.all()

    return jsonify([
        product.to_dict(currency)
        for product in products
    ]), 200




# Get Single Product
# @product_bp.route("/products/<int:id>", methods=["GET"])
# def get_product(id):

#     product = Product.query.get(id)

#     if not product:
#         return jsonify({
#             "error": "Product not found"
#         }), 404

#     return jsonify(
#         product.to_dict()
#     ), 200


@product_bp.route("/products/<int:id>", methods=["GET"])
def get_product(id):

    product = Product.query.get(id)

    if not product:
        return jsonify({
            "error": "Product not found"
        }), 404

    currency = request.headers.get(
        "X-Currency",
        "INR"
    )

    return jsonify(
        product.to_dict(currency)
    ), 200

# Update Product
@product_bp.route("/products/<int:id>", methods=["PUT"])
def update_product(id):

    product = Product.query.get(id)

    if not product:
        return jsonify({"error": "Product not found"}), 404

    data = request.get_json()

    product.name = data.get("name", product.name)
    product.description = data.get("description", product.description)

    product.category_id = data.get("category_id", product.category_id)

    product.price = data.get("price", product.price)
    product.original_price = data.get("original_price", product.original_price)

    product.stock = data.get("stock", product.stock)
    product.unit = data.get("unit", product.unit)

    product.image_url = data.get("image_url", product.image_url)

    # 🔥 THIS IS YOUR ISSUE
    product.ingredients = data.get("ingredients", product.ingredients)

    # 🔥 ALSO IMPORTANT
    if "is_active" in data:
        product.is_active = data.get("is_active")

    db.session.commit()

    return jsonify({
        "message": "Product updated successfully",
        "product": product.to_dict()
    }), 200

@product_bp.route("/products/<int:id>", methods=["DELETE"])
def delete_product(id):
    try:
        product = Product.query.get(id)

        if not product:
            return jsonify({"error": "Product not found"}), 404

        from models.wishlist import Wishlist

        Wishlist.query.filter_by(product_id=id).delete()

        db.session.delete(product)
        db.session.commit()

        return jsonify({
            "message": "Product deleted successfully"
        }), 200

    except Exception as e:
        db.session.rollback()
        print("DELETE ERROR:", e)
        return jsonify({"error": str(e)}), 500
