from flask import Blueprint, request, jsonify
from extensions import db
from models.address import Address

address_bp = Blueprint("address", __name__)

@address_bp.route("/addresses", methods=["POST"])
def create_address():

    data = request.get_json()

    if not data or "user_id" not in data:
        return jsonify({"error": "user_id is required"}), 400

    address = Address(
        user_id=data["user_id"],
        street=data.get("street"),
        city=data.get("city"),
        state=data.get("state"),
        pincode=data.get("pincode"),
        country=data.get("country", "India")
    )

    db.session.add(address)
    db.session.commit()

    return jsonify({
        "message": "Address added successfully",
        "address": address.to_dict()
    }), 201



@address_bp.route("/users/<int:user_id>/addresses", methods=["GET"])
def get_user_addresses(user_id):

    addresses = Address.query.filter_by(user_id=user_id).all()

    return jsonify({
        "user_id": user_id,
        "addresses": [a.to_dict() for a in addresses]
    }), 200


@address_bp.route("/addresses/<int:id>", methods=["GET"])
def get_address(id):

    address = Address.query.get(id)

    if not address:
        return jsonify({"error": "Address not found"}), 404

    return jsonify(address.to_dict()), 200


@address_bp.route("/addresses/<int:id>", methods=["PUT"])
def update_address(id):

    address = Address.query.get(id)

    if not address:
        return jsonify({"error": "Address not found"}), 404

    data = request.get_json()

    address.street = data.get("street", address.street)
    address.city = data.get("city", address.city)
    address.state = data.get("state", address.state)
    address.pincode = data.get("pincode", address.pincode)
    address.country = data.get("country", address.country)

    db.session.commit()

    return jsonify({
        "message": "Address updated successfully",
        "address": address.to_dict()
    }), 200


@address_bp.route("/addresses/<int:id>", methods=["DELETE"])
def delete_address(id):

    address = Address.query.get(id)

    if not address:
        return jsonify({"error": "Address not found"}), 404

    db.session.delete(address)
    db.session.commit()

    return jsonify({
        "message": "Address deleted successfully"
    }), 200