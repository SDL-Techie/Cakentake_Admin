# from flask import Blueprint, request, jsonify
# from flask_jwt_extended import jwt_required, get_jwt_identity
# from datetime import datetime
# from extensions import db
# from models.order import Order
# from models.user import User
# from models.misc import DeliverySlot
# from middleware.role import role_required
# from services.order_history_service import log_order_status

# delivery_bp = Blueprint("delivery", __name__)


# # # @delivery_bp.route("/delivery/pending", methods=["GET"])
# # # @jwt_required()
# # # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # # def delivery_pending():
# # #     orders = Order.query.filter_by(status="ACCEPTED").all()
# # #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200

# @delivery_bp.route("/delivery/pending", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def delivery_pending():

#     orders = Order.query.filter(
#         Order.status == "READY_FOR_DISPATCH"
#     ).order_by(Order.created_at.desc()).all()

#     return jsonify({
#         "orders": [o.to_dict() for o in orders]
#     }), 200



# # @delivery_bp.route("/delivery/ready-for-pickup", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT", "DRIVER"])
# # def delivery_ready():
# #     orders = Order.query.filter_by(status="READY").all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @delivery_bp.route("/delivery/<int:order_id>/assign-driver", methods=["POST"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def assign_driver(order_id):
# #     data = request.get_json()
# #     order = Order.query.get_or_404(order_id)
# #     driver = User.query.filter_by(id=data["driver_id"], role="DRIVER").first()
# #     if not driver:
# #         return jsonify({"error": "Driver not found"}), 404
# #     order.driver_id = driver.id
# #     order.driver_assigned_by = int(get_jwt_identity())
# #     order.driver_assigned_at = datetime.utcnow()
# #     db.session.commit()
# #     return jsonify({"message": "Driver assigned", "order": order.to_dict()}), 200


# # @delivery_bp.route("/delivery/assigned", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def delivery_assigned():
# #     orders = Order.query.filter(
# #         Order.driver_id.isnot(None),
# #         Order.status == "READY"
# #     ).all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @delivery_bp.route("/delivery/delivered", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def delivery_delivered():
# #     orders = Order.query.filter_by(status="DELIVERED").order_by(Order.delivered_at.desc()).all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @delivery_bp.route("/delivery/driver/<int:driver_id>", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def delivery_by_driver(driver_id):
# #     orders = Order.query.filter_by(driver_id=driver_id).all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @delivery_bp.route("/delivery/<int:order_id>/on-way", methods=["POST"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT", "DRIVER"])
# # def mark_on_way(order_id):
# #     order = Order.query.get_or_404(order_id)
# #     order.status = "OUT_FOR_DELIVERY"
# #     order.out_for_delivery_at = datetime.utcnow()
# #     log_order_status(order.id, "OUT_FOR_DELIVERY", int(get_jwt_identity()))
# #     db.session.commit()
# #     return jsonify({"message": "Order is out for delivery", "order": order.to_dict()}), 200


# # @delivery_bp.route("/delivery/<int:order_id>/delivered", methods=["POST"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT", "DRIVER"])
# # def mark_delivered(order_id):
# #     order = Order.query.get_or_404(order_id)
# #     order.status = "DELIVERED"
# #     order.delivered_at = datetime.utcnow()
# #     log_order_status(order.id, "DELIVERED", int(get_jwt_identity()))
# #     db.session.commit()
# #     return jsonify({"message": "Order delivered", "order": order.to_dict()}), 200


# # @delivery_bp.route("/delivery/report", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER"])
# # def delivery_report():
# #     delivered = Order.query.filter_by(status="DELIVERED").count()
# #     pending = Order.query.filter(
# #         Order.status.notin_(["DELIVERED", "CANCELLED"])
# #     ).count()
# #     return jsonify({"delivered": delivered, "pending": pending}), 200


# # @delivery_bp.route("/delivery/area-wise-report", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER"])
# # def area_wise_report():
# #     from sqlalchemy import func
# #     results = db.session.query(
# #         Order.delivery_area_id,
# #         func.count(Order.id).label("count")
# #     ).group_by(Order.delivery_area_id).all()
# #     return jsonify({
# #         "area_wise": [{"area_id": r[0], "order_count": r[1]} for r in results]
# #     }), 200


# # # ─── DELIVERY SLOTS ──────────────────────────────────────────────────────────

# # @delivery_bp.route("/delivery-slots", methods=["GET"])
# # @jwt_required()
# # def get_delivery_slots():
# #     slots = DeliverySlot.query.filter_by(is_active=True).all()
# #     return jsonify({"slots": [s.to_dict() for s in slots]}), 200


# # @delivery_bp.route("/delivery-slots", methods=["POST"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER"])
# # def create_delivery_slot():
# #     data = request.get_json()
# #     slot = DeliverySlot(
# #         label=data["label"],
# #         start_time=data["start_time"],
# #         end_time=data["end_time"],
# #         max_orders=data.get("max_orders", 20)
# #     )
# #     db.session.add(slot)
# #     db.session.commit()
# #     return jsonify({"message": "Slot created", "slot": slot.to_dict()}), 201


# # @delivery_bp.route("/delivery-slots/<int:slot_id>", methods=["PUT"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER"])
# # def update_delivery_slot(slot_id):
# #     slot = DeliverySlot.query.get_or_404(slot_id)
# #     data = request.get_json()
# #     for field in ["label", "start_time", "end_time", "max_orders", "is_active"]:
# #         if field in data:
# #             setattr(slot, field, data[field])
# #     db.session.commit()
# #     return jsonify({"message": "Slot updated", "slot": slot.to_dict()}), 200


# # @delivery_bp.route("/delivery-slots/<int:slot_id>", methods=["DELETE"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER"])
# # def delete_delivery_slot(slot_id):
# #     slot = DeliverySlot.query.get_or_404(slot_id)
# #     db.session.delete(slot)
# #     db.session.commit()
# #     return jsonify({"message": "Slot deleted"}), 200


# # # ─── DELIVERY AGENTS ─────────────────────────────────────────────────────────

# # @delivery_bp.route("/delivery-agents/<int:agent_id>/orders", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def agent_orders(agent_id):
# #     orders = Order.query.filter_by(driver_id=agent_id).all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @delivery_bp.route("/delivery-agents/<int:agent_id>/report", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER"])
# # def agent_report(agent_id):
# #     orders = Order.query.filter_by(driver_id=agent_id).all()
# #     delivered = [o for o in orders if o.status == "DELIVERED"]
# #     return jsonify({
# #         "agent_id": agent_id,
# #         "total_orders": len(orders),
# #         "delivered": len(delivered)
# #     }), 200


# # @delivery_bp.route("/delivery-agents/<int:agent_id>/dashboard", methods=["GET"])
# # @jwt_required()
# # def agent_dashboard(agent_id):
# #     agent = User.query.get_or_404(agent_id)
# #     orders = Order.query.filter_by(driver_id=agent_id).all()
# #     return jsonify({
# #         "agent": agent.to_dict(),
# #         "total": len(orders),
# #         "delivered": sum(1 for o in orders if o.status == "DELIVERED"),
# #         "active": sum(1 for o in orders if o.status in ["READY", "OUT_FOR_DELIVERY"])
# #     }), 200



# @delivery_bp.route("/delivery/<int:order_id>/assign-driver", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def assign_driver(order_id):
#     data = request.get_json()

#     order = Order.query.get_or_404(order_id)

#     driver = User.query.filter_by(
#         id=data["driver_id"],
#         role="DRIVER"
#     ).first()

#     if not driver:
#         return jsonify({"error": "Driver not found"}), 404

#     order.driver_id = driver.id
#     order.driver_assigned_by = int(get_jwt_identity())
#     order.driver_assigned_at = datetime.utcnow()
#     order.status = "DRIVER_ASSIGNED"

#     db.session.commit()

#     return jsonify({
#         "message": "Driver assigned successfully",
#         "order": order.to_dict()
#     }), 200


# #Ready for Pickup
# @delivery_bp.route("/delivery/ready-for-pickup", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def delivery_ready():

#     orders = Order.query.filter(
#         Order.status == "READY_FOR_PICKUP"
#     ).order_by(Order.created_at.desc()).all()

#     return jsonify({
#         "orders": [o.to_dict() for o in orders]
#     }), 200


# #Assigned Orders
# @delivery_bp.route("/delivery/assigned", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN","SHOP_MANAGER","DELIVERY_AGENT"])
# def delivery_assigned():

#     current_user = User.query.get(int(get_jwt_identity()))

#     if current_user.role == "DELIVERY_AGENT":

#         orders = Order.query.filter(
#             Order.driver_id == current_user.id,
#             Order.status.in_([
#                 "ASSIGNED_TO_DRIVER",
#                 "OUT_FOR_DELIVERY",
#                 "DELIVERY_COMPLETED_PENDING_APPROVAL"
#             ])
#         ).order_by(Order.created_at.desc()).all()

#     else:

#         orders = Order.query.filter(
#             Order.driver_id.isnot(None),
#             Order.status.in_([
#                 "ASSIGNED_TO_DRIVER",
#                 "OUT_FOR_DELIVERY",
#                 "DELIVERY_COMPLETED_PENDING_APPROVAL"
#             ])
#         ).order_by(Order.created_at.desc()).all()

#     return jsonify({
#         "orders":[o.to_dict() for o in orders]
#     }),200


# #Delivered Orders

# @delivery_bp.route("/delivery/delivered", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def delivery_delivered():

#     orders = Order.query.filter(
#         Order.status == "DELIVERED"
#     ).order_by(Order.delivered_at.desc()).all()

#     return jsonify({
#         "orders": [o.to_dict() for o in orders]
#     }), 200

# #Driver Dashboard
# @delivery_bp.route("/delivery-agents/<int:agent_id>/dashboard", methods=["GET"])
# @jwt_required()
# def agent_dashboard(agent_id):

#     agent = User.query.get_or_404(agent_id)

#     orders = Order.query.filter_by(
#         driver_id=agent_id
#     ).all()

#     return jsonify({
#         "agent": agent.to_dict(),
#         "total": len(orders),
#         "delivered": sum(
#             1 for o in orders
#             if o.status == "DELIVERED"
#         ),
#         "active": sum(
#             1 for o in orders
#             if o.status in [
#                 "ASSIGNED_TO_DRIVER",
#                 "OUT_FOR_DELIVERY",
#                 "DELIVERY_COMPLETED_PENDING_APPROVAL"
#             ]
#         )
#     }), 200



"""
delivery_routes.py

Endpoints consumed by DeliveryOrder.tsx (the Delivery Agent's dashboard).
A DELIVERY_AGENT:
  - sees orders in ASSIGNED_TO_AGENT / ASSIGNED_TO_DRIVER / DRIVER_ACCEPTED /
    OUT_FOR_DELIVERY / DELIVERY_SUBMITTED that belong to them
  - assigns an available DRIVER to those orders
  - confirms final delivery after driver submits proof

All driver assignment is done via order_routes.py /orders/:id/assign-driver,
which already allows DELIVERY_AGENT role.  The endpoints here are
*list/query* endpoints the agent's dashboard needs.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from extensions import db
from models.order import Order
from models.user import User
from middleware.role import role_required
from services.order_history_service import log_order_status

delivery_bp = Blueprint("delivery", __name__)


# ─── Orders visible to the delivery agent ────────────────────────────────────

@delivery_bp.route("/delivery/pending", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def delivery_pending():
    """
    Orders that are READY (kitchen done, awaiting agent assignment).
    Admin / shop manager see all; delivery agent sees only their own.
    """
    current_user = User.query.get(int(get_jwt_identity()))

    orders = Order.query.filter(
        Order.status == "READY"
    ).order_by(Order.created_at.desc()).all()

    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@delivery_bp.route("/delivery/assigned", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def delivery_assigned():
    """
    Orders in ASSIGNED_TO_AGENT state (agent assigned, driver not yet picked).
    """
    current_user = User.query.get(int(get_jwt_identity()))

    if current_user.role == "DELIVERY_AGENT":
        orders = Order.query.filter(
            Order.delivery_agent_id == current_user.id,
            Order.status == "ASSIGNED_TO_AGENT"
        ).order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.filter(
            Order.status == "ASSIGNED_TO_AGENT"
        ).order_by(Order.created_at.desc()).all()

    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@delivery_bp.route("/delivery/ready-for-pickup", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def delivery_ready():
    """
    Orders where a driver has been picked by this agent but not yet accepted.
    Also includes OUT_FOR_DELIVERY (driver is en route).
    """
    current_user = User.query.get(int(get_jwt_identity()))

    statuses = ["ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY"]

    if current_user.role == "DELIVERY_AGENT":
        orders = Order.query.filter(
            Order.delivery_agent_id == current_user.id,
            Order.status.in_(statuses)
        ).order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.filter(
            Order.status.in_(statuses)
        ).order_by(Order.created_at.desc()).all()

    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@delivery_bp.route("/delivery/delivered", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def delivery_delivered():
    """
    Orders fully confirmed as DELIVERED (delivery agent confirmed).
    """
    current_user = User.query.get(int(get_jwt_identity()))

    if current_user.role == "DELIVERY_AGENT":
        orders = Order.query.filter(
            Order.delivery_agent_id == current_user.id,
            Order.status == "DELIVERED"
        ).order_by(Order.delivered_at.desc()).all()
    else:
        orders = Order.query.filter(
            Order.status == "DELIVERED"
        ).order_by(Order.delivered_at.desc()).all()

    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@delivery_bp.route("/delivery/proof-pending", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def delivery_proof_pending():
    """
    Orders where driver has submitted proof and delivery agent needs to confirm.
    Status: DELIVERY_SUBMITTED
    """
    current_user = User.query.get(int(get_jwt_identity()))

    if current_user.role == "DELIVERY_AGENT":
        orders = Order.query.filter(
            Order.delivery_agent_id == current_user.id,
            Order.status == "DELIVERY_SUBMITTED"
        ).order_by(Order.created_at.desc()).all()
    else:
        orders = Order.query.filter(
            Order.status == "DELIVERY_SUBMITTED"
        ).order_by(Order.created_at.desc()).all()

    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# ─── Delivery agent dashboard ────────────────────────────────────────────────

@delivery_bp.route("/delivery-agents/<int:agent_id>/dashboard", methods=["GET"])
@jwt_required()
def agent_dashboard(agent_id):
    agent = User.query.get_or_404(agent_id)
    orders = Order.query.filter_by(delivery_agent_id=agent_id).all()

    return jsonify({
        "agent": agent.to_dict(),
        "total": len(orders),
        "delivered": sum(1 for o in orders if o.status == "DELIVERED"),
        "active": sum(
            1 for o in orders
            if o.status in [
                "ASSIGNED_TO_AGENT", "ASSIGNED_TO_DRIVER",
                "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"
            ]
        ),
        "pending_confirmation": sum(1 for o in orders if o.status == "DELIVERY_SUBMITTED"),
    }), 200


@delivery_bp.route("/delivery-agents/<int:agent_id>/orders", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def agent_orders(agent_id):
    orders = Order.query.filter_by(
        delivery_agent_id=agent_id
    ).order_by(Order.created_at.desc()).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200