from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from extensions import db
from models.area import Area
from models.order import Order
from middleware.role import role_required

area_bp = Blueprint("area", __name__)

ALLOWED_CURRENCIES = ["USD", "AED", "SAR", "INR", "KWD" , "SGD"]

@area_bp.route("/areas", methods=["GET"])
def get_areas():
    areas = Area.query.filter_by(is_active=True).all()
    return jsonify({"areas": [a.to_dict() for a in areas]}), 200


@area_bp.route("/areas/<int:area_id>", methods=["GET"])
def get_area(area_id):
    area = Area.query.get_or_404(area_id)
    return jsonify({"area": area.to_dict()}), 200


@area_bp.route("/areas", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def create_area():
    data = request.get_json()
    currency = data.get("currency", "AED").upper()

    if currency not in ALLOWED_CURRENCIES:
        return jsonify({
            "message": "Invalid currency",
            "allowed_currencies": ALLOWED_CURRENCIES
        }), 400
    
    area = Area(
        name=data["name"],
        city=data.get("city"),
        state=data.get("state"),
        pincode=data.get("pincode"),
        delivery_charge=data.get("delivery_charge", 0),
        min_order_value=data.get("min_order_value", 0),
        currency=currency
    )
    db.session.add(area)
    db.session.commit()
    return jsonify({"message": "Area created", "area": area.to_dict()}), 201


@area_bp.route("/areas/<int:area_id>", methods=["PUT"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def update_area(area_id):
    area = Area.query.get_or_404(area_id)
    data = request.get_json()


    if "currency" in data:
        currency = data["currency"].upper()

        if currency not in ALLOWED_CURRENCIES:
            return jsonify({
                "message": "Invalid currency",
                "allowed_currencies": ALLOWED_CURRENCIES
            }), 400

        area.currency = currency

    # for field in ["name", "city", "state", "pincode", "delivery_charge", "min_order_value",   "currency", "is_active"]:
    for field in [
        "name",
        "city",
        "state",
        "pincode",
        "delivery_charge",
        "min_order_value",
        "is_active"
    ]:
        if field in data:
            setattr(area, field, data[field])
    db.session.commit()
    return jsonify({"message": "Area updated", "area": area.to_dict()}), 200


@area_bp.route("/areas/<int:area_id>", methods=["DELETE"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def delete_area(area_id):
    area = Area.query.get_or_404(area_id)
    db.session.delete(area)
    db.session.commit()
    return jsonify({"message": "Area deleted"}), 200


@area_bp.route("/areas/<int:area_id>/set-charge", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def set_area_charge(area_id):
    area = Area.query.get_or_404(area_id)
    data = request.get_json()
    area.delivery_charge = data["delivery_charge"]
    db.session.commit()
    return jsonify({"message": "Delivery charge updated", "area": area.to_dict()}), 200


@area_bp.route("/areas/<int:area_id>/set-min-order", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def set_area_min_order(area_id):
    area = Area.query.get_or_404(area_id)
    data = request.get_json()
    area.min_order_value = data["min_order_value"]
    db.session.commit()
    return jsonify({"message": "Min order updated", "area": area.to_dict()}), 200


@area_bp.route("/areas/<int:area_id>/orders", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def area_orders(area_id):
    orders = Order.query.filter_by(delivery_area_id=area_id).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# @area_bp.route("/areas/check-delivery", methods=["POST"])
# def check_delivery():

    data = request.get_json()

    pincode = str(data.get("pincode", "")).strip()
    order_amount = float(data.get("order_amount", 0))

    if not pincode:
        return jsonify({
            "success": False,
            "message": "Pincode is required"
        }), 400

    area = Area.query.filter_by(
        pincode=pincode,
        is_active=True
    ).first()

    if not area:
        return jsonify({
            "success": False,
            "delivery_available": False,
            "message": "Delivery is not available for this area."
        }), 404

    if order_amount < float(area.min_order_value):
        return jsonify({
            "success": False,
            "delivery_available": True,
            "message": f"Minimum order value for your area is {area.currency} {float(area.min_order_value):.2f}.",
            "area": {
                "id": area.id,
                "name": area.name,
                "city": area.city,
                "state": area.state,
                "pincode": area.pincode,
                "currency": area.currency,
                "delivery_charge": float(area.delivery_charge),
                "min_order_value": float(area.min_order_value)
            }
        }), 400

    return jsonify({
        "success": True,
        "delivery_available": True,
        "message": "Delivery available.",
        "area": {
            "id": area.id,
            "pincode": area.pincode,
            "currency": area.currency,
            "delivery_charge": float(area.delivery_charge),
            "min_order_value": float(area.min_order_value)
        }
    }), 200



@area_bp.route("/areas/check-delivery", methods=["POST"])
def check_delivery():
    data = request.get_json()

    area_id = data.get("area_id")
    order_amount = float(data.get("order_amount", 0))

    if not area_id:
        return jsonify({
            "success": False,
            "message": "Area is required"
        }), 400

    area = Area.query.filter_by(
        id=area_id,
        is_active=True
    ).first()

    if not area:
        return jsonify({
            "success": False,
            "delivery_available": False,
            "message": "Delivery is not available for this area."
        }), 404

    if order_amount < float(area.min_order_value):
        return jsonify({
            "success": False,
            "delivery_available": True,
            "message": f"Minimum order value for {area.name} is {area.currency} {float(area.min_order_value):.2f}.",
            "area": area.to_dict()
        }), 400

    return jsonify({
        "success": True,
        "delivery_available": True,
        "message": "Delivery available.",
        "area": area.to_dict(),
        "delivery_charge": float(area.delivery_charge),
        "min_order_value": float(area.min_order_value),
        "currency": area.currency
    }), 200