from flask import Blueprint, request, jsonify
from extensions import db
from models.cart import Cart
from models.cartItem import CartItem
from models.product import Product
from models.user import User

cart_bp = Blueprint(
    "cart",
    __name__
)

@cart_bp.route("/cart", methods=["POST"])
def add_to_cart():

    data = request.get_json()

    if not data or "user_id" not in data or "product_id" not in data:
        return jsonify({"error": "user_id and product_id are required"}), 400

    user_id = data["user_id"]
    product_id = data["product_id"]
    quantity = data.get("quantity", 1)

    if not isinstance(quantity, int) or quantity < 1:
        return jsonify({"error": "quantity must be a positive integer"}), 400

    product = Product.query.get(product_id)
    if not product:
        return jsonify({"error": "Product not found"}), 404

    cart = Cart.query.filter_by(
        user_id=user_id
    ).first()
    if not cart:
        cart = Cart(
            user_id=user_id
        )

        db.session.add(cart)
        db.session.flush()

    cart_item = CartItem.query.filter_by(
        cart_id=cart.id,
        product_id=product_id
    ).first()

    if cart_item:
        cart_item.quantity += quantity

    else:
        cart_item = CartItem(
            cart_id=cart.id,
            product_id=product_id,
            quantity=quantity
        )

        db.session.add(cart_item)

    db.session.commit()

    return jsonify({
        "message": "Added to cart",
        "cart": cart.to_dict()
    }), 201


# @cart_bp.route("/cart/<int:user_id>", methods=["GET"])
# def get_cart(user_id):

#     cart = Cart.query.filter_by(
#         user_id=user_id
#     ).first()

#     if not cart:
#         return jsonify({
#             "message": "Cart is empty"
#         }), 404

#     total = 0

#     items = []

#     for item in cart.items:

#         subtotal = (
#             float(item.product.price)
#             * item.quantity
#         )

#         total += subtotal

#         items.append({
#             "id": item.id,
#             "quantity": item.quantity,
#             "subtotal": subtotal,

#             "product": {
#                 "id": item.product.id,
#                 "name": item.product.name,
#                 "price": float(item.product.price),
#                 "image_url": item.product.image_url
#             }
#         })

#     return jsonify({
#         "cart_id": cart.id,
#         "user_id": cart.user_id,
#         "total": total,
#         "items": items
#     }), 200


@cart_bp.route("/cart/<int:user_id>", methods=["GET"])
def get_cart(user_id):

    cart = Cart.query.filter_by(user_id=user_id).first()

    if not cart:
        return jsonify({
            "message": "Cart is empty"
        }), 404

    # currency = request.headers.get("X-Currency", "INR")
    currency = request.headers.get("X-Currency", "INR")
    print("Currency received:", currency)


    total = 0
    items = []

    for item in cart.items:

        product = item.product.to_dict(currency)

        subtotal = product["price"] * item.quantity

        total += subtotal

        items.append({
            "id": item.id,
            "quantity": item.quantity,
            "subtotal": subtotal,
            "product": product
        })

    return jsonify({
        "cart_id": cart.id,
        "user_id": cart.user_id,
        "total": total,
        "currency": currency,
        "items": items
    }), 200

@cart_bp.route("/cart/item/<int:item_id>", methods=["PUT"])
def update_cart_item(item_id):

    item = CartItem.query.get(item_id)

    if not item:
        return jsonify({
            "error": "Cart item not found"
        }), 404

    data = request.get_json()

    item.quantity = data["quantity"]

    db.session.commit()

    return jsonify({
        "message": "Quantity updated"
    }), 200

@cart_bp.route("/cart/item/<int:item_id>", methods=["DELETE"])
def remove_cart_item(item_id):

    item = CartItem.query.get(item_id)

    if not item:
        return jsonify({
            "error": "Cart item not found"
        }), 404

    db.session.delete(item)
    db.session.commit()

    return jsonify({
        "message": "Item removed from cart"
    }), 200

@cart_bp.route("/cart/<int:user_id>", methods=["DELETE"])
def clear_cart(user_id):

    cart = Cart.query.filter_by(
        user_id=user_id
    ).first()

    if not cart:
        return jsonify({
            "error": "Cart not found"
        }), 404

    CartItem.query.filter_by(
        cart_id=cart.id
    ).delete()

    db.session.commit()

    return jsonify({
        "message": "Cart cleared"
    }), 200

# @cart_bp.route("/cart/<int:user_id>", methods=["DELETE"])
# def clear_cart(user_id):

    cart = Cart.query.filter_by(
        user_id=user_id
    ).first()

    if not cart:
        return jsonify({
            "error": "Cart not found"
        }), 404

    CartItem.query.filter_by(
        cart_id=cart.id
    ).delete()

    db.session.commit()

    return jsonify({
        "message": "Cart cleared"
    }), 200