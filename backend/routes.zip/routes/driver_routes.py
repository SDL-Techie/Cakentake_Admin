# # from flask import Blueprint, request, jsonify
# # from flask_jwt_extended import jwt_required, get_jwt_identity
# # from datetime import datetime
# # from extensions import db
# # from models.user import User
# # from models.order import Order
# # from middleware.role import role_required
# # from services.order_history_service import log_order_status

# # driver_bp = Blueprint("driver", __name__)


# # @driver_bp.route("/drivers", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def get_drivers():
# #     drivers = User.query.filter_by(role="DRIVER").all()
# #     return jsonify({"drivers": [d.to_dict() for d in drivers]}), 200


# # @driver_bp.route("/drivers/available", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def get_available_drivers():
# #     # Drivers with no active deliveries
# #     busy_ids = db.session.query(Order.driver_id).filter(
# #         Order.status.in_(["READY", "OUT_FOR_DELIVERY","DELIVERY_COMPLETED_PENDING_APPROVAL"]),
# #         Order.driver_id.isnot(None)
# #     ).subquery()
# #     drivers = User.query.filter_by(role="DRIVER").filter(
# #         ~User.id.in_(busy_ids)
# #     ).all()
# #     return jsonify({"drivers": [d.to_dict() for d in drivers]}), 200


# # @driver_bp.route("/drivers/<int:driver_id>/dashboard", methods=["GET"])
# # @jwt_required()
# # def driver_dashboard(driver_id):
# #     driver = User.query.get_or_404(driver_id)
# #     orders = Order.query.filter_by(driver_id=driver_id).all()
# #     return jsonify({
# #         "driver": driver.to_dict(),
# #         "total_orders": len(orders),
# #         "delivered": sum(1 for o in orders if o.status == "DELIVERED"),
# #         "active": sum(1 for o in orders if o.status in ["READY", "OUT_FOR_DELIVERY",  "DELIVERY_COMPLETED_PENDING_APPROVAL"])
# #     }), 200


# # @driver_bp.route("/drivers/<int:driver_id>/assigned", methods=["GET"])
# # @jwt_required()
# # def driver_assigned(driver_id):
# #     orders = Order.query.filter(
# #         Order.driver_id == driver_id,
# #         Order.status.in_(["READY", "OUT_FOR_DELIVERY",  "DELIVERY_COMPLETED_PENDING_APPROVAL"])
# #     ).all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @driver_bp.route("/drivers/<int:driver_id>/completed", methods=["GET"])
# # @jwt_required()
# # def driver_completed(driver_id):
# #     orders = Order.query.filter_by(driver_id=driver_id, status="DELIVERED").all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @driver_bp.route("/drivers/<int:order_id>/delivered", methods=["POST"])
# # @jwt_required()
# # @role_required(["DRIVER", "DELIVERY_AGENT", "ADMIN"])
# # def driver_mark_delivered(order_id):
# #     order = Order.query.get_or_404(order_id)
# #     data = request.get_json() or {}
# #     order.status = "DELIVERED"
# #     order.delivered_at = datetime.utcnow()
# #     order.delivery_notes = data.get("notes")
# #     order.customer_confirmation_name = data.get("customer_name")
# #     order.customer_confirmation_phone = data.get("customer_phone")
# #     log_order_status(order.id, "DELIVERED", int(get_jwt_identity()))
# #     db.session.commit()
# #     return jsonify({"message": "Delivery confirmed", "order": order.to_dict()}), 200


# # @driver_bp.route("/drivers/<int:driver_id>/report", methods=["GET"])
# # @jwt_required()
# # def driver_report(driver_id):
# #     orders = Order.query.filter_by(driver_id=driver_id).all()
# #     return jsonify({
# #         "driver_id": driver_id,
# #         "total": len(orders),
# #         "delivered": sum(1 for o in orders if o.status == "DELIVERED"),
# #         "cancelled": sum(1 for o in orders if o.status == "CANCELLED")
# #     }), 200


# # @driver_bp.route("/drivers/<int:driver_id>/status", methods=["POST"])
# # @jwt_required()
# # @role_required(["DRIVER", "ADMIN"])
# # def update_driver_status(driver_id):
# #     data = request.get_json()
# #     driver = User.query.get_or_404(driver_id)
# #     # Store status in a simple field if available; extend model as needed
# #     return jsonify({"message": "Status updated", "driver_id": driver_id}), 200


# # # @driver_bp.route("/drivers/<int:order_id>/accept", methods=["POST"])
# # # @jwt_required()
# # # @role_required(["DRIVER"])
# # # def driver_accept(order_id):
# # #     order = Order.query.get_or_404(order_id)
# # #     order.driver_accepted_at = datetime.utcnow()
# # #     db.session.commit()
# # #     return jsonify({"message": "Order accepted", "order": order.to_dict()}), 200


# # @driver_bp.route("/drivers/<int:order_id>/accept", methods=["POST"])
# # @jwt_required()
# # @role_required(["DRIVER"])
# # def driver_accept(order_id):
# #     order = Order.query.get_or_404(order_id)

# #     order.driver_accepted_at = datetime.utcnow()
# #     order.status = "ON_THE_WAY"

# #     db.session.commit()

# #     return jsonify({
# #         "message": "Order accepted",
# #         "order": order.to_dict()
# #     }), 200

# # @driver_bp.route("/drivers/<int:order_id>/reject", methods=["POST"])
# # @jwt_required()
# # @role_required(["DRIVER"])
# # def driver_reject(order_id):
# #     order = Order.query.get_or_404(order_id)
# #     order.driver_id = None
# #     order.driver_assigned_at = None
# #     db.session.commit()
# #     return jsonify({"message": "Order rejected", "order": order.to_dict()}), 200




# from flask import Blueprint, request, jsonify
# from flask_jwt_extended import jwt_required, get_jwt_identity
# from datetime import datetime
# from extensions import db
# from models.user import User
# from models.order import Order
# from middleware.role import role_required

# driver_bp = Blueprint("driver", __name__)


# # ─── Driver lists (admin / agent) ────────────────────────────────────────────

# @driver_bp.route("/drivers", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def get_drivers():
#     """
#     All users with role=DRIVER.
#     Used by the delivery agent's driver picker.
#     """
#     drivers = User.query.filter_by(role="DRIVER").all()
#     return jsonify({"drivers": [d.to_dict() for d in drivers]}), 200


# @driver_bp.route("/drivers/available", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def get_available_drivers():
#     """
#     Drivers with role=DRIVER and no currently active order.
#     "Active" means status IN (ASSIGNED_TO_DRIVER, DRIVER_ACCEPTED,
#     OUT_FOR_DELIVERY, DELIVERY_SUBMITTED).
#     """
#     busy_driver_ids = db.session.query(Order.driver_id).filter(
#         Order.status.in_([
#             "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
#             "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"
#         ]),
#         Order.driver_id.isnot(None)
#     ).subquery()

#     drivers = User.query.filter_by(role="DRIVER").filter(
#         ~User.id.in_(busy_driver_ids)
#     ).all()

#     return jsonify({"drivers": [d.to_dict() for d in drivers]}), 200


# # ─── Driver dashboard ─────────────────────────────────────────────────────────

# @driver_bp.route("/drivers/<int:driver_id>/dashboard", methods=["GET"])
# @jwt_required()
# def driver_dashboard(driver_id):
#     """
#     Summary stats for a driver's dashboard.
#     Used in DriverOrder.tsx header section.
#     """
#     driver = User.query.get_or_404(driver_id)
#     orders = Order.query.filter_by(driver_id=driver_id).all()

#     return jsonify({
#         "driver": driver.to_dict(),
#         "total_orders": len(orders),
#         "delivered": sum(1 for o in orders if o.status == "DELIVERED"),
#         "active": sum(
#             1 for o in orders
#             if o.status in [
#                 "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
#                 "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"
#             ]
#         ),
#         # today_earnings / rating would need separate tracking tables;
#         # kept here as stubs for future extension.
#         "today_earnings": 0,
#         "rating": float(driver.rating or 0),
#     }), 200


# # ─── Driver's order lists ─────────────────────────────────────────────────────

# @driver_bp.route("/drivers/<int:driver_id>/assigned", methods=["GET"])
# @jwt_required()
# def driver_assigned(driver_id):
#     """
#     Active orders currently assigned to this driver.
#     Includes: ASSIGNED_TO_DRIVER, DRIVER_ACCEPTED, OUT_FOR_DELIVERY, DELIVERY_SUBMITTED.
#     """
#     orders = Order.query.filter(
#         Order.driver_id == driver_id,
#         Order.status.in_([
#             "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
#             "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"
#         ])
#     ).order_by(Order.created_at.desc()).all()

#     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# @driver_bp.route("/drivers/<int:driver_id>/completed", methods=["GET"])
# @jwt_required()
# def driver_completed(driver_id):
#     """Delivered orders completed by this driver."""
#     orders = Order.query.filter_by(
#         driver_id=driver_id, status="DELIVERED"
#     ).order_by(Order.delivered_at.desc()).all()

#     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # ─── Driver availability status ───────────────────────────────────────────────

# @driver_bp.route("/drivers/<int:driver_id>/status", methods=["POST"])
# @jwt_required()
# @role_required(["DRIVER", "ADMIN"])
# def update_driver_status(driver_id):
#     """
#     POST body: { "status": "ONLINE" | "BUSY" | "OFFLINE" }
#     Updates User.availability_status (added in fixed User model).
#     """
#     data   = request.get_json() or {}
#     driver = User.query.get_or_404(driver_id)
#     new_status = (data.get("status") or "OFFLINE").upper()

#     if new_status not in ("ONLINE", "BUSY", "OFFLINE"):
#         return jsonify({"error": "status must be ONLINE, BUSY, or OFFLINE"}), 400

#     driver.availability_status = new_status
#     db.session.commit()

#     return jsonify({
#         "message": "Status updated",
#         "driver_id": driver_id,
#         "status": new_status
#     }), 200


# # ─── Driver report ────────────────────────────────────────────────────────────

# @driver_bp.route("/drivers/<int:driver_id>/report", methods=["GET"])
# @jwt_required()
# def driver_report(driver_id):
#     orders = Order.query.filter_by(driver_id=driver_id).all()
#     return jsonify({
#         "driver_id": driver_id,
#         "total": len(orders),
#         "delivered":  sum(1 for o in orders if o.status == "DELIVERED"),
#         "cancelled":  sum(1 for o in orders if o.status == "CANCELLED"),
#         "in_progress": sum(1 for o in orders if o.status in [
#             "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
#             "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"
#         ]),
#     }), 200


from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from extensions import db
from models.user import User
from models.order import Order
from models.misc import DriverSettlement
from middleware.role import role_required

driver_bp = Blueprint("driver", __name__)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _settlement_dict(s: DriverSettlement) -> dict:
    """Full serialisation of a DriverSettlement (extends model's to_dict)."""
    return {
        "id": s.id,
        "driver_id": s.driver_id,
        "amount": float(s.amount),
        "orders_count": s.orders_count or 0,
        "period_start": s.period_start.isoformat() if s.period_start else None,
        "period_end": s.period_end.isoformat() if s.period_end else None,
        "status": s.status,
        "paid_at": s.paid_at.isoformat() if s.paid_at else None,
        "paid_by": s.paid_by,
        "notes": s.notes,
        "payment_source": s.payment_source or "CASH",
        "reference": s.reference,
        "created_at": s.created_at.isoformat() if s.created_at else None,
        "driver": {
            "id": s.driver.id,
            "first_name": s.driver.first_name,
            "last_name": s.driver.last_name,
            "phone_no": s.driver.phone_no,
        } if s.driver else None,
    }


# ─── Driver lists (admin / agent) ─────────────────────────────────────────────

@driver_bp.route("/drivers", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def get_drivers():
    """All users with role=DRIVER."""
    drivers = User.query.filter_by(role="DRIVER").all()
    return jsonify({"drivers": [d.to_dict() for d in drivers]}), 200


@driver_bp.route("/drivers/available", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def get_available_drivers():
    """
    Drivers who have no currently active order.
    Active = ASSIGNED_TO_DRIVER | DRIVER_ACCEPTED | OUT_FOR_DELIVERY | DELIVERY_SUBMITTED.
    """
    busy_driver_ids = db.session.query(Order.driver_id).filter(
        Order.status.in_([
            "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
            "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED",
        ]),
        Order.driver_id.isnot(None),
    ).subquery()

    drivers = User.query.filter_by(role="DRIVER").filter(
        ~User.id.in_(busy_driver_ids)
    ).all()
    return jsonify({"drivers": [d.to_dict() for d in drivers]}), 200


# ─── Driver dashboard ──────────────────────────────────────────────────────────

@driver_bp.route("/drivers/<int:driver_id>/dashboard", methods=["GET"])
@jwt_required()
def driver_dashboard(driver_id):
    """Summary stats for a driver's dashboard header."""
    driver = User.query.get_or_404(driver_id)
    orders = Order.query.filter_by(driver_id=driver_id).all()

    pending_settlements = DriverSettlement.query.filter_by(
        driver_id=driver_id, status="PENDING"
    ).all()
    paid_settlements = DriverSettlement.query.filter_by(
        driver_id=driver_id, status="PAID"
    ).all()

    pending_amount = sum(float(s.amount) for s in pending_settlements)
    total_earned   = sum(float(s.amount) for s in paid_settlements)

    return jsonify({
        "driver": driver.to_dict(),
        "total_orders": len(orders),
        "delivered": sum(1 for o in orders if o.status == "DELIVERED"),
        "active": sum(
            1 for o in orders
            if o.status in [
                "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
                "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED",
            ]
        ),
        "pending_amount": pending_amount,
        "total_earned": total_earned,
        "rating": float(driver.rating or 0),
    }), 200


# ─── Driver order lists ────────────────────────────────────────────────────────

@driver_bp.route("/drivers/<int:driver_id>/assigned", methods=["GET"])
@jwt_required()
def driver_assigned(driver_id):
    """
    Active orders assigned to this driver.
    Statuses: ASSIGNED_TO_DRIVER | DRIVER_ACCEPTED | OUT_FOR_DELIVERY | DELIVERY_SUBMITTED.
    """
    orders = Order.query.filter(
        Order.driver_id == driver_id,
        Order.status.in_([
            "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
            "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED",
        ]),
    ).order_by(Order.created_at.desc()).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@driver_bp.route("/drivers/<int:driver_id>/completed", methods=["GET"])
@jwt_required()
def driver_completed(driver_id):
    """Delivered orders completed by this driver."""
    orders = Order.query.filter_by(
        driver_id=driver_id, status="DELIVERED"
    ).order_by(Order.delivered_at.desc()).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# ─── Driver availability status ────────────────────────────────────────────────

@driver_bp.route("/drivers/<int:driver_id>/status", methods=["POST"])
@jwt_required()
@role_required(["DRIVER", "ADMIN"])
def update_driver_status(driver_id):
    """
    POST { "status": "ONLINE" | "BUSY" | "OFFLINE" }
    Updates User.availability_status.
    """
    data       = request.get_json() or {}
    driver     = User.query.get_or_404(driver_id)
    new_status = (data.get("status") or "OFFLINE").upper()

    if new_status not in ("ONLINE", "BUSY", "OFFLINE"):
        return jsonify({"error": "status must be ONLINE, BUSY, or OFFLINE"}), 400

    driver.availability_status = new_status
    db.session.commit()

    return jsonify({
        "message": "Status updated",
        "driver_id": driver_id,
        "status": new_status,
    }), 200


# ─── Driver report ─────────────────────────────────────────────────────────────

@driver_bp.route("/drivers/<int:driver_id>/report", methods=["GET"])
@jwt_required()
def driver_report(driver_id):
    orders = Order.query.filter_by(driver_id=driver_id).all()
    return jsonify({
        "driver_id": driver_id,
        "total": len(orders),
        "delivered":   sum(1 for o in orders if o.status == "DELIVERED"),
        "cancelled":   sum(1 for o in orders if o.status == "CANCELLED"),
        "in_progress": sum(
            1 for o in orders if o.status in [
                "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
                "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED",
            ]
        ),
    }), 200


# ─── Unsettled delivered orders ────────────────────────────────────────────────

@driver_bp.route("/drivers/<int:driver_id>/unsettled-orders", methods=["GET"])
@jwt_required()
def get_unsettled_orders(driver_id):
    """
    Orders with status=DELIVERED that have not been included in any settlement yet.
    Used by admin to build a settlement batch, and by driver to see what's pending.
    """
    orders = Order.query.filter_by(
        driver_id=driver_id,
        status="DELIVERED",
        is_driver_settled=False,
    ).order_by(Order.delivered_at.desc()).all()

    total_delivery_charges = sum(float(o.delivery_charge or 0) for o in orders)

    return jsonify({
        "orders": [o.to_dict() for o in orders],
        "count": len(orders),
        "total_delivery_charges": total_delivery_charges,
    }), 200


# ─── Settlement routes ─────────────────────────────────────────────────────────

@driver_bp.route("/drivers/<int:driver_id>/settlements", methods=["GET"])
@jwt_required()
def get_driver_settlements(driver_id):
    """Driver views their own settlement history with aggregate totals."""
    settlements = DriverSettlement.query.filter_by(
        driver_id=driver_id
    ).order_by(DriverSettlement.created_at.desc()).all()

    total_pending    = sum(float(s.amount) for s in settlements if s.status == "PENDING")
    total_paid       = sum(float(s.amount) for s in settlements if s.status == "PAID")
    orders_settled   = sum((s.orders_count or 0) for s in settlements if s.status == "PAID")

    return jsonify({
        "settlements": [_settlement_dict(s) for s in settlements],
        "total_pending": total_pending,
        "total_paid": total_paid,
        "orders_settled": orders_settled,
    }), 200


@driver_bp.route("/driver-settlements", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def get_all_settlements():
    """Admin / shop manager views all settlements, optionally filtered."""
    driver_id_filter = request.args.get("driver_id", type=int)
    status_filter    = request.args.get("status")

    query = DriverSettlement.query
    if driver_id_filter:
        query = query.filter_by(driver_id=driver_id_filter)
    if status_filter:
        query = query.filter_by(status=status_filter.upper())

    settlements = query.order_by(DriverSettlement.created_at.desc()).all()
    return jsonify({
        "settlements": [_settlement_dict(s) for s in settlements],
        "count": len(settlements),
    }), 200


@driver_bp.route("/driver-settlements", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def create_settlement():
    """
    Admin creates a settlement — assigns a pay amount to a driver
    for a batch of delivered orders.

    Body:
    {
        "driver_id": int,
        "amount": float,                  # total amount to pay the driver
        "order_ids": [int, ...],          # optional — orders to mark settled
        "orders_count": int,              # used when order_ids is omitted
        "period_start": "ISO datetime",   # optional
        "period_end":   "ISO datetime",   # optional
        "notes": str,
        "payment_source": "CASH"|"BANK",
        "reference": str
    }
    """
    data = request.get_json() or {}

    driver_id = data.get("driver_id")
    amount    = data.get("amount")

    if not driver_id or amount is None:
        return jsonify({"error": "driver_id and amount are required"}), 400

    driver = User.query.get(driver_id)
    if not driver or driver.role != "DRIVER":
        return jsonify({"error": "Driver not found"}), 404

    order_ids    = data.get("order_ids") or []
    orders_count = len(order_ids) if order_ids else int(data.get("orders_count", 0))

    settlement = DriverSettlement(
        driver_id      = driver_id,
        amount         = float(amount),
        orders_count   = orders_count,
        period_start   = (
            datetime.fromisoformat(data["period_start"])
            if data.get("period_start") else None
        ),
        period_end     = (
            datetime.fromisoformat(data["period_end"])
            if data.get("period_end") else None
        ),
        notes          = data.get("notes"),
        payment_source = data.get("payment_source", "CASH"),
        reference      = data.get("reference"),
        status         = "PENDING",
    )

    db.session.add(settlement)
    db.session.flush()  # populate settlement.id before linking orders

    # Mark specified orders as settled and link them to this settlement
    for oid in order_ids:
        order = Order.query.get(oid)
        if order and order.driver_id == driver_id and order.status == "DELIVERED":
            order.is_driver_settled    = True
            order.driver_settlement_id = settlement.id

    db.session.commit()

    return jsonify({
        "message": "Settlement created",
        "settlement": _settlement_dict(settlement),
    }), 201


@driver_bp.route("/driver-settlements/<int:settlement_id>/pay", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def mark_settlement_paid(settlement_id):
    """
    Owner / shop manager pays the driver — marks settlement as PAID.
    Body: { "payment_source": "CASH"|"BANK", "reference": str }
    """
    data       = request.get_json() or {}
    settlement = DriverSettlement.query.get_or_404(settlement_id)

    if settlement.status == "PAID":
        return jsonify({"error": "Settlement is already paid"}), 400

    settlement.status         = "PAID"
    settlement.paid_at        = datetime.utcnow()
    settlement.paid_by        = int(get_jwt_identity())
    if data.get("payment_source"):
        settlement.payment_source = data["payment_source"]
    if data.get("reference"):
        settlement.reference      = data["reference"]

    db.session.commit()

    return jsonify({
        "message": "Settlement marked as paid",
        "settlement": _settlement_dict(settlement),
    }), 200


@driver_bp.route("/driver-settlements/<int:settlement_id>", methods=["GET"])
@jwt_required()
def get_settlement_detail(settlement_id):
    """Retrieve a settlement with all linked orders."""
    settlement = DriverSettlement.query.get_or_404(settlement_id)
    orders     = Order.query.filter_by(driver_settlement_id=settlement_id).all()
    result     = _settlement_dict(settlement)
    result["orders"] = [o.to_dict() for o in orders]
    return jsonify({"settlement": result}), 200
