from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime, timedelta
from extensions import db
from models.order import Order
from models.user import User
from middleware.role import role_required
from services.order_history_service import log_order_status

kitchen_bp = Blueprint("kitchen", __name__)


# @kitchen_bp.route("/kitchen/orders/pending", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
# def kitchen_pending():
#     orders = Order.query.filter_by(status="ACCEPTED").order_by(Order.created_at).all()
#     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@kitchen_bp.route("/kitchen/orders/pending", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def kitchen_pending():
    orders = Order.query.filter(
        Order.status == "ASSIGNED_TO_KITCHEN"
    ).order_by(Order.created_at).all()

    return jsonify({"orders": [o.to_dict() for o in orders]}), 200
        
@kitchen_bp.route("/kitchen/orders/processing", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def kitchen_processing():
    #orders = Order.query.filter_by(status="PROCESSING").order_by(Order.created_at).all()
    orders = Order.query.filter_by(status="PREPARING").order_by(Order.created_at).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@kitchen_bp.route("/kitchen/orders/completed", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def kitchen_completed():
    orders = Order.query.filter_by(status="READY").order_by(Order.created_at.desc()).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@kitchen_bp.route("/kitchen/<int:order_id>/start-processing", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def start_processing(order_id):
    order = Order.query.get_or_404(order_id)
    if order.status != "ACCEPTED":
        return jsonify({"error": "Order must be ACCEPTED before processing"}), 400
    order.status="PREPARING"
    order.preparation_started_at = datetime.utcnow()
    log_order_status(order.id, "PROCESSING", int(get_jwt_identity()))
    db.session.commit()
    return jsonify({"message": "Processing started", "order": order.to_dict()}), 200


@kitchen_bp.route("/kitchen/assigned-orders", methods=["GET"])
@jwt_required()
@role_required(["KITCHEN_STAFF"])
def kitchen_assigned_orders():
    user_id = int(get_jwt_identity())
    orders = Order.query.filter_by(kitchen_staff_id=user_id).filter(
        Order.status.in_(["ASSIGNED_TO_KITCHEN","PREPARING"])
    ).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@kitchen_bp.route("/kitchen/<int:order_id>/complete", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def complete_kitchen(order_id):
    order = Order.query.get_or_404(order_id)
    if order.status != "PREPARING":
        return jsonify({"error": "Order must be PROCESSING to mark complete"}), 400
    order.status = "READY"
    order.completed_by_kitchen_at = datetime.utcnow()
    log_order_status(order.id, "READY", int(get_jwt_identity()))
    db.session.commit()
    return jsonify({"message": "Order marked as READY", "order": order.to_dict()}), 200


@kitchen_bp.route("/kitchen/<int:order_id>/reassign", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def reassign_kitchen(order_id):
    data = request.get_json()
    order = Order.query.get_or_404(order_id)
    staff = User.query.filter_by(id=data["kitchen_staff_id"], role="KITCHEN_STAFF").first()
    if not staff:
        return jsonify({"error": "Kitchen staff not found"}), 404
    order.kitchen_staff_id = staff.id
    order.kitchen_assigned_by = int(get_jwt_identity())
    order.kitchen_assigned_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"message": "Kitchen staff reassigned", "order": order.to_dict()}), 200


@kitchen_bp.route("/kitchen/<int:order_id>/details", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def kitchen_order_details(order_id):
    order = Order.query.get_or_404(order_id)
    return jsonify({"order": order.to_dict()}), 200


def _kitchen_report(days):
    from sqlalchemy import func
    since = datetime.utcnow() - timedelta(days=days)
    orders = Order.query.filter(
        Order.status == "DELIVERED",
        Order.completed_by_kitchen_at >= since
    ).all()
    return jsonify({
        "period_days": days,
        "total_completed": len(orders),
        "orders": [o.to_dict() for o in orders]
    }), 200


@kitchen_bp.route("/kitchen/report/day", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def kitchen_report_day():
    return _kitchen_report(1)


@kitchen_bp.route("/kitchen/report/week", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def kitchen_report_week():
    return _kitchen_report(7)


@kitchen_bp.route("/kitchen/report/month", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "KITCHEN_STAFF"])
def kitchen_report_month():
    return _kitchen_report(30)
