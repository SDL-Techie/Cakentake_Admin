from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from extensions import db
from models.loyalty import LoyaltyConfig, LoyaltyLedger
from models.user import User
from services.loyalty_service import get_loyalty_config, redeem_loyalty_points
from middleware.role import role_required

loyalty_bp = Blueprint("loyalty", __name__)


@loyalty_bp.route("/loyalty-config", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def create_config():
    data = request.get_json()

    # Prevent creating multiple configs
    existing = LoyaltyConfig.query.first()
    if existing:
        return jsonify({
            "error": "Loyalty configuration already exists. Use Update instead."
        }), 400

    config = LoyaltyConfig(
        points_per_order=data["points_per_order"],
        points_value=data["points_value"],
        min_redemption=data["min_redemption"],
        max_redemption_percent=data["max_redemption_percent"],
        is_active=data.get("is_active", True)
    )

    db.session.add(config)
    db.session.commit()

    return jsonify({
        "message": "Loyalty configuration created successfully",
        "config": config.to_dict()
    }), 201


@loyalty_bp.route("/loyalty-config", methods=["GET"])
@jwt_required()
def get_config():
    config = get_loyalty_config()
    return jsonify({"config": config.to_dict()}), 200


@loyalty_bp.route("/loyalty-config", methods=["PUT"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def update_config():
    config = get_loyalty_config()
    data = request.get_json()
    for field in ["points_per_order", "points_value", "min_redemption", "max_redemption_percent", "is_active"]:
        if field in data:
            setattr(config, field, data[field])
    db.session.commit()
    return jsonify({"message": "Loyalty config updated", "config": config.to_dict()}), 200


@loyalty_bp.route("/loyalty-points/<int:customer_id>", methods=["GET"])
@jwt_required()
def get_points(customer_id):
    user = User.query.get_or_404(customer_id)
    return jsonify({"customer_id": customer_id, "points": user.loyalty_points or 0}), 200


@loyalty_bp.route("/loyalty-points/<int:customer_id>/redeem", methods=["POST"])
@jwt_required()
def redeem_points(customer_id):
    data = request.get_json()
    points = data.get("points")
    if not points:
        return jsonify({"error": "points is required"}), 400
    result = redeem_loyalty_points(customer_id, points, data.get("order_id"))
    if "error" in result:
        return jsonify(result), 400
    return jsonify(result), 200


@loyalty_bp.route("/loyalty-points/report", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def loyalty_report():
    total_earned = db.session.query(
        db.func.sum(LoyaltyLedger.points)
    ).filter(LoyaltyLedger.transaction_type == "EARN").scalar() or 0

    total_redeemed = db.session.query(
        db.func.sum(LoyaltyLedger.points)
    ).filter(LoyaltyLedger.transaction_type == "REDEEM").scalar() or 0

    return jsonify({
        "total_earned": total_earned,
        "total_redeemed": abs(total_redeemed),
        "net_outstanding": total_earned - abs(total_redeemed)
    }), 200


@loyalty_bp.route("/loyalty/ledger", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def get_ledger():
    page = request.args.get("page", 1, type=int)
    ledger = LoyaltyLedger.query.order_by(
        LoyaltyLedger.created_at.desc()
    ).paginate(page=page, per_page=50, error_out=False)
    return jsonify({"ledger": [l.to_dict() for l in ledger.items], "total": ledger.total}), 200


@loyalty_bp.route("/loyalty/ledger/<int:customer_id>", methods=["GET"])
@jwt_required()
def get_customer_ledger(customer_id):
    ledger = LoyaltyLedger.query.filter_by(customer_id=customer_id).order_by(
        LoyaltyLedger.created_at.desc()
    ).all()
    return jsonify({"ledger": [l.to_dict() for l in ledger]}), 200
