# import stripe
# import random
# from datetime import datetime
# from flask import Blueprint, request, jsonify
# from flask_jwt_extended import jwt_required, get_jwt_identity

# from extensions import db
# from config import Config

# from models.order import Order
# from models.order_item import OrderItem
# from models.product import Product
# from models.user import User
# from models.address import Address

# from services.point_service import add_points
# from services.notification_service import send_order_notification
# from middleware.role import role_required
# from services.order_history_service import log_order_status

# from models.area import Area


# order_bp = Blueprint("order", __name__)

# # ─── UTILS ─────────────────────────────────────────────────────────────────

# def get_current_user():
#     user_id = get_jwt_identity()
#     return User.query.get(int(user_id))


# def generate_order_number():
#     return f"CT-{datetime.now().strftime('%Y%m%d')}-{random.randint(1000,9999)}"


# def build_n8n_payload(order):
#     return {
#         "body": {
#             "order": {
#                 "orderId": order.id,
#                 "total": float(order.total),
#                 "items": [
#                     {
#                         "name": item.product.name,
#                         "quantity": item.quantity,
#                         "price": float(item.price)
#                     } for item in order.items
#                 ]
#             },
#             "customer": {
#                 "name": f"{order.customer.first_name} {order.customer.last_name}",
#                 "email": order.customer.email,
#                 "phone": order.customer.phone_no
#             },
#             "admin": {
#                 "email": "orders@caketake.com",
#                 "phone": "9198778945"
#             }
#         }
#     }


# def notify_admins(message, order=None):
#     """Best-effort notification to admin / shop manager. Never raises."""
#     try:
#         send_order_notification({
#             "message": message,
#             "order_id": order.id if order else None,
#             "order_number": order.order_number if order else None,
#         })
#     except Exception as e:
#         print("Notification error:", str(e))


# # ─── CREATE ORDER ────────────────────────────────────────────────────────────

# # @order_bp.route("/orders", methods=["POST"])
# # @jwt_required()
# # def create_order():

# #     user = get_current_user()
# #     data = request.get_json()

# #     if not data:
# #         return jsonify({"error": "No data provided"}), 400

# #     required_fields = ["address_id", "items"]
# #     for field in required_fields:
# #         if field not in data:
# #             return jsonify({"error": f"{field} is required"}), 400

# #     address = Address.query.get(data["address_id"])
# #     if not address:
# #         return jsonify({"error": "Address not found"}), 404

# #     items_data = data["items"]
# #     if not items_data:
# #         return jsonify({"error": "Order must contain at least one item"}), 400

# #     payment_method = (data.get("payment_method") or "COD").upper()

# #     order = Order(
# #         user_id=user.id,
# #         created_by=user.id,
# #         order_number=generate_order_number(),
# #         order_type=data.get("order_type", "direct_order"),
# #         address_id=address.id,
# #         delivery_date=datetime.strptime(
# #             data["delivery_date"], "%Y-%m-%d"
# #         ).date() if data.get("delivery_date") else None,
# #         delivery_time_slot=data.get("delivery_time_slot"),
# #         payment_method=payment_method,
# #         payment_status="PENDING",
# #         status="PENDING",
# #         total=0
# #     )

# #     db.session.add(order)
# #     db.session.flush()

# #     total_amount = 0

# #     for item in items_data:

# #         product = Product.query.get(item["product_id"])
# #         if not product:
# #             return jsonify({"error": f"Product {item['product_id']} not found"}), 404

# #         quantity = item.get("quantity", 1)

# #         item_total = float(product.price) * quantity
# #         total_amount += item_total

# #         order_item = OrderItem(
# #             order_id=order.id,
# #             product_id=product.id,
# #             quantity=quantity,
# #             price=product.price,
# #             line_total=item_total,
# #             custom_json=item.get("custom_json")
# #         )

# #         db.session.add(order_item)

# #     delivery_charge = float(data.get("delivery_charge", 0))
# #     discount = float(data.get("discount", 0))
# #     grand_total = total_amount + delivery_charge - discount

# #     order.subtotal = total_amount
# #     order.delivery_charge = delivery_charge
# #     order.discount = discount
# #     order.grand_total = grand_total
# #     order.loyalty_coupon = data.get("loyalty_coupon")
# #     order.currency = data.get("currency", "INR")
# #     order.total = grand_total

# #     try:
# #         add_points(user.phone_no, total_amount)
# #     except Exception as e:
# #         print("Loyalty points error:", str(e))

# #     db.session.commit()

# #     try:
# #         send_order_notification(build_n8n_payload(order))
# #     except Exception as e:
# #         print("Notification Error:", str(e))

# #     return jsonify({
# #         "message": "Order created successfully",
# #         "order": order.to_dict()
# #     }), 201


# # ─── CREATE ORDER ────────────────────────────────────────────────────────────

# @order_bp.route("/orders", methods=["POST"])
# @jwt_required()
# def create_order():

#     user = get_current_user()
#     data = request.get_json()

#     if not data:
#         return jsonify({"error": "No data provided"}), 400

#     required_fields = ["address_id", "items", "delivery_area_id"]
#     for field in required_fields:
#         if field not in data:
#             return jsonify({"error": f"{field} is required"}), 400

#     address = Address.query.get(data["address_id"])
#     if not address:
#         return jsonify({"error": "Address not found"}), 404

#     area = Area.query.filter_by(
#         id=data["delivery_area_id"],
#         is_active=True
#     ).first()

#     if not area:
#         return jsonify({"error": "Invalid delivery area"}), 400

#     items_data = data["items"]
#     if not items_data:
#         return jsonify({"error": "Order must contain at least one item"}), 400

#     payment_method = (data.get("payment_method") or "COD").upper()

#     order = Order(
#         user_id=user.id,
#         created_by=user.id,
#         order_number=generate_order_number(),
#         order_type=data.get("order_type", "direct_order"),
#         address_id=address.id,
#         delivery_area_id=area.id,
#         delivery_date=datetime.strptime(
#             data["delivery_date"], "%Y-%m-%d"
#         ).date() if data.get("delivery_date") else None,
#         delivery_time_slot=data.get("delivery_time_slot"),
#         payment_method=payment_method,
#         payment_status="PENDING",
#         status="PENDING",
#         total=0
#     )

#     db.session.add(order)
#     db.session.flush()

#     total_amount = 0

#     for item in items_data:
#         product = Product.query.get(item["product_id"])

#         if not product:
#             return jsonify({
#                 "error": f"Product {item['product_id']} not found"
#             }), 404

#         quantity = item.get("quantity", 1)

#         item_total = float(product.price) * quantity
#         total_amount += item_total

#         order_item = OrderItem(
#             order_id=order.id,
#             product_id=product.id,
#             quantity=quantity,
#             price=product.price,
#             line_total=item_total,
#             custom_json=item.get("custom_json")
#         )

#         db.session.add(order_item)

#     if total_amount < float(area.min_order_value):
#         db.session.rollback()
#         return jsonify({
#             "error": f"Minimum order value for {area.name} is {area.currency} {float(area.min_order_value):.2f}"
#         }), 400

#     delivery_charge = float(area.delivery_charge)
#     discount = float(data.get("discount", 0))
#     grand_total = total_amount + delivery_charge - discount

#     order.subtotal = total_amount
#     order.delivery_charge = delivery_charge
#     order.discount = discount
#     order.grand_total = grand_total
#     order.loyalty_coupon = data.get("loyalty_coupon")
#     order.currency = area.currency
#     order.total = grand_total

#     try:
#         add_points(user.phone_no, total_amount)
#     except Exception as e:
#         print("Loyalty points error:", str(e))

#     db.session.commit()

#     try:
#         send_order_notification(build_n8n_payload(order))
#     except Exception as e:
#         print("Notification Error:", str(e))

#     return jsonify({
#         "message": "Order created successfully",
#         "order": order.to_dict()
#     }), 201

# # ─── GET ALL ORDERS (ROLE BASED) ────────────────────────────────────────────

# @order_bp.route("/orders", methods=["GET"])
# @jwt_required()
# def get_orders():

#     user = get_current_user()
#     status = request.args.get("status")

#     query = Order.query

#     if user.role == "USER":
#         query = query.filter_by(user_id=user.id)

#     elif user.role == "KITCHEN_STAFF":
#         query = query.filter(
#             Order.kitchen_staff_id == user.id,
#             Order.status.in_(["ASSIGNED_TO_KITCHEN", "PREPARING"])
#         )

#     elif user.role == "DELIVERY_AGENT":
#         query = query.filter(
#             db.or_(
#                 Order.delivery_agent_id == user.id,
#                 Order.status == "ASSIGNED_TO_AGENT"
#             )
#         )

#     elif user.role == "DRIVER":
#         query = query.filter(Order.driver_id == user.id)

#     elif user.role in ("ADMIN", "SHOP_MANAGER", "SALES_AGENT"):
#         pass  # full access

#     if status:
#         query = query.filter_by(status=status.upper())

#     orders = query.order_by(Order.created_at.desc()).all()

#     return jsonify({
#         "count": len(orders),
#         "orders": [o.to_dict() for o in orders]
#     }), 200


# # ─── GET SINGLE ORDER ────────────────────────────────────────────────────────

# @order_bp.route("/orders/<int:id>", methods=["GET"])
# @jwt_required()
# def get_order(id):

#     order = Order.query.get(id)

#     if not order:
#         return jsonify({"error": "Order not found"}), 404

#     return jsonify(order.to_dict()), 200


# # ─── UPDATE ORDER (ADMIN / SHOP MANAGER) ────────────────────────────────────

# @order_bp.route("/orders/<int:id>", methods=["PUT"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def update_order(id):

#     order = Order.query.get(id)
#     if not order:
#         return jsonify({"error": "Order not found"}), 404

#     data = request.get_json()

#     order.status = data.get("status", order.status)
#     order.payment_status = data.get("payment_status", order.payment_status)

#     db.session.commit()

#     return jsonify({
#         "message": "Order updated successfully",
#         "order": order.to_dict()
#     }), 200


# # ─── DELETE ORDER (ADMIN) ────────────────────────────────────────────────────

# @order_bp.route("/orders/<int:id>", methods=["DELETE"])
# @jwt_required()
# @role_required(["ADMIN"])
# def delete_order(id):

#     order = Order.query.get(id)

#     if not order:
#         return jsonify({"error": "Order not found"}), 404

#     db.session.delete(order)
#     db.session.commit()

#     return jsonify({"message": "Order deleted successfully"}), 200


# # ─── STRIPE CHECKOUT (kept for card payments) ───────────────────────────────

# @order_bp.route("/create-checkout-session", methods=["POST"])
# @jwt_required()
# def create_checkout_session():

#     data = request.get_json()
#     amount = int(float(data["amount"]) * 100)

#     session = stripe.checkout.Session.create(
#         payment_method_types=["card"],
#         line_items=[{
#             "price_data": {
#                 "currency": "inr",
#                 "product_data": {"name": "Bakery Order"},
#                 "unit_amount": amount
#             },
#             "quantity": 1
#         }],
#         mode="payment",
#         success_url="http://localhost:3000/payment-success?session_id={CHECKOUT_SESSION_ID}",
#         cancel_url="http://localhost:3000/payment-cancel"
#     )

#     return jsonify({
#         "session_id": session.id,
#         "url": session.url
#     }), 200


# # ─── USER ORDERS ─────────────────────────────────────────────────────────────

# @order_bp.route("/orders/user/<int:user_id>", methods=["GET"])
# @jwt_required()
# def get_user_orders(user_id):

#     orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()

#     return jsonify({
#         "count": len(orders),
#         "orders": [o.to_dict() for o in orders]
#     }), 200


# # ══════════════════════════════════════════════════════════════════════════
# #  WORKFLOW: accept -> kitchen -> ready -> agent -> driver -> delivered
# # ══════════════════════════════════════════════════════════════════════════

# # ─── 1. ACCEPT ORDER (sets payment_status from COD / UPI) ──────────────────

# @order_bp.route("/orders/<int:id>/accept", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def accept_order(id):

#     order = Order.query.get_or_404(id)

#     if order.status != "PENDING":
#         return jsonify({"error": "Only pending orders can be accepted"}), 400

#     old_status = order.status
#     current_user = get_current_user()

#     data = request.get_json(silent=True) or {}

#     # Payment method can be confirmed/overridden at accept time, otherwise
#     # whatever was set at order creation is used.
#     payment_method = (data.get("payment_method") or order.payment_method or "COD").upper()
#     order.payment_method = payment_method

#     if payment_method == "COD":
#         order.payment_status = "PENDING"
#     elif payment_method == "UPI":
#         order.payment_status = "COMPLETED"
#     # any other method (CARD/STRIPE) is left as-is; those flows set
#     # payment_status themselves via /payments/* routes.

#     order.status = "ACCEPTED"

#     log_order_status(
#         order,
#         old_status,
#         "ACCEPTED",
#         current_user.id,
#         f"Order accepted. Payment method: {payment_method}, payment_status: {order.payment_status}"
#     )

#     db.session.commit()

#     notify_admins(f"Order {order.order_number} accepted ({payment_method})", order)

#     return jsonify({
#         "message": "Order accepted",
#         "order": order.to_dict()
#     }), 200


# @order_bp.route("/orders/<int:order_id>/reject", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def reject_order(order_id):

#     order = Order.query.get_or_404(order_id)
#     data = request.get_json() or {}

#     if order.status != "PENDING":
#         return jsonify({"error": "Only pending orders can be rejected"}), 400

#     old_status = order.status
#     order.status = "REJECTED"
#     order.rejection_reason = data.get("reason")

#     log_order_status(order, old_status, "REJECTED", get_current_user().id, data.get("reason"))

#     db.session.commit()

#     return jsonify({
#         "message": "Order rejected",
#         "order": order.to_dict()
#     }), 200


# @order_bp.route("/orders/<int:order_id>/cancel", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "SALES_AGENT"])
# def cancel_order(order_id):
#     order = Order.query.get_or_404(order_id)
#     if order.status in ("DELIVERED", "CANCELLED"):
#         return jsonify({"error": f"Cannot cancel an order that is {order.status}"}), 400

#     data = request.get_json() or {}
#     old_status = order.status
#     order.status = "CANCELLED"
#     order.rejection_reason = data.get("reason")

#     log_order_status(order, old_status, "CANCELLED", get_current_user().id, data.get("reason"))

#     db.session.commit()
#     return jsonify({"message": "Order cancelled", "order": order.to_dict()}), 200


# # ─── 2. ASSIGN TO KITCHEN ────────────────────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/assign-kitchen", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def assign_kitchen(order_id):

#     order = Order.query.get_or_404(order_id)

#     if order.status != "ACCEPTED":
#         return jsonify({"error": "Order must be ACCEPTED before assigning to kitchen"}), 400

#     data = request.get_json()
#     kitchen_staff_id = data.get("kitchen_staff_id")

#     kitchen_staff = User.query.get(kitchen_staff_id)
#     if not kitchen_staff:
#         return jsonify({"error": "Kitchen staff not found"}), 404
#     if kitchen_staff.role != "KITCHEN_STAFF":
#         return jsonify({"error": "Selected user is not kitchen staff"}), 400

#     old_status = order.status

#     order.kitchen_staff_id = kitchen_staff.id
#     order.kitchen_assigned_by = get_current_user().id
#     order.kitchen_assigned_at = datetime.utcnow()
#     order.status = "ASSIGNED_TO_KITCHEN"

#     log_order_status(order, old_status, "ASSIGNED_TO_KITCHEN", get_current_user().id)

#     db.session.commit()

#     return jsonify({
#         "message": "Kitchen assigned",
#         "order": order.to_dict()
#     }), 200


# @order_bp.route("/orders/<int:order_id>/reassign-kitchen", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def reassign_kitchen(order_id):
#     order = Order.query.get_or_404(order_id)
#     data = request.get_json()

#     staff = User.query.filter_by(id=data.get("kitchen_staff_id"), role="KITCHEN_STAFF").first()
#     if not staff:
#         return jsonify({"error": "Kitchen staff not found"}), 404

#     order.kitchen_staff_id = staff.id
#     order.kitchen_assigned_by = get_current_user().id
#     order.kitchen_assigned_at = datetime.utcnow()

#     db.session.commit()
#     return jsonify({"message": "Kitchen staff reassigned", "order": order.to_dict()}), 200


# @order_bp.route("/kitchen-staff", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def get_kitchen_staff():
#     staff = User.query.filter_by(role="KITCHEN_STAFF").all()
#     return jsonify([
#         {"id": s.id, "name": f"{s.first_name} {s.last_name}"}
#         for s in staff
#     ]), 200


# # ─── 3. KITCHEN: PREPARING -> READY ─────────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/start-preparation", methods=["POST"])
# @jwt_required()
# @role_required(["KITCHEN_STAFF", "ADMIN", "SHOP_MANAGER"])
# def start_preparation(order_id):

#     order = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if current_user.role == "KITCHEN_STAFF" and order.kitchen_staff_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     if order.status != "ASSIGNED_TO_KITCHEN":
#         return jsonify({"error": "Order must be ASSIGNED_TO_KITCHEN to start preparation"}), 400

#     old_status = order.status
#     order.status = "PREPARING"
#     order.preparation_started_at = datetime.utcnow()

#     log_order_status(order, old_status, "PREPARING", current_user.id)

#     db.session.commit()

#     return jsonify({
#         "message": "Preparation started",
#         "order": order.to_dict()
#     }), 200


# @order_bp.route("/orders/<int:order_id>/ready", methods=["POST"])
# @jwt_required()
# @role_required(["KITCHEN_STAFF", "ADMIN", "SHOP_MANAGER"])
# def mark_ready(order_id):

#     order = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if current_user.role == "KITCHEN_STAFF" and order.kitchen_staff_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     if order.status != "PREPARING":
#         return jsonify({"error": "Order must be PREPARING before it can be marked READY"}), 400

#     old_status = order.status
#     order.status = "READY"
#     order.completed_by_kitchen_at = datetime.utcnow()

#     log_order_status(order, old_status, "READY", current_user.id)

#     db.session.commit()

#     notify_admins(f"Order {order.order_number} is READY for dispatch", order)

#     return jsonify({
#         "message": "Order marked READY",
#         "order": order.to_dict()
#     }), 200


# # ─── 4. ASSIGN TO DELIVERY AGENT (owner/shop manager -> DELIVERY_AGENT) ─────

# @order_bp.route("/orders/<int:order_id>/assign-agent", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def assign_delivery_agent(order_id):

#     order = Order.query.get_or_404(order_id)

#     if order.status != "READY":
#         return jsonify({"error": "Order must be READY before assigning a delivery agent"}), 400

#     data = request.get_json()
#     agent_id = data.get("delivery_agent_id") or data.get("agent_id")

#     if not agent_id:
#         return jsonify({"error": "delivery_agent_id is required"}), 400

#     agent = User.query.get(agent_id)
#     if not agent:
#         return jsonify({"error": "Delivery agent not found"}), 404
#     if agent.role != "DELIVERY_AGENT":
#         return jsonify({"error": "Selected user is not a delivery agent"}), 400

#     old_status = order.status
#     current_user = get_current_user()

#     order.delivery_agent_id = agent.id
#     order.delivery_agent_assigned_by = current_user.id
#     order.delivery_agent_assigned_at = datetime.utcnow()
#     order.status = "ASSIGNED_TO_AGENT"

#     log_order_status(
#         order, old_status, "ASSIGNED_TO_AGENT", current_user.id,
#         f"Assigned to delivery agent {agent.first_name} {agent.last_name}"
#     )

#     db.session.commit()

#     notify_admins(
#         f"Order {order.order_number} assigned to delivery agent "
#         f"{agent.first_name} {agent.last_name}",
#         order
#     )

#     return jsonify({
#         "message": "Delivery agent assigned",
#         "order": order.to_dict()
#     }), 200


# @order_bp.route("/orders/<int:order_id>/reassign-agent", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def reassign_delivery_agent(order_id):
#     order = Order.query.get_or_404(order_id)
#     data = request.get_json()

#     agent = User.query.filter_by(
#         id=data.get("delivery_agent_id"), role="DELIVERY_AGENT"
#     ).first()
#     if not agent:
#         return jsonify({"error": "Delivery agent not found"}), 404

#     order.delivery_agent_id = agent.id
#     order.delivery_agent_assigned_by = get_current_user().id
#     order.delivery_agent_assigned_at = datetime.utcnow()

#     # Reassigning the agent also clears any driver previously picked by the
#     # old agent, since the new agent should choose their own driver.
#     order.driver_id = None
#     order.driver_assigned_by = None
#     order.driver_assigned_at = None
#     order.driver_accepted_at = None
#     if order.status in ("ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY"):
#         order.status = "ASSIGNED_TO_AGENT"

#     db.session.commit()
#     return jsonify({"message": "Delivery agent reassigned", "order": order.to_dict()}), 200


# @order_bp.route("/delivery-agents", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def get_delivery_agents():
#     agents = User.query.filter_by(role="DELIVERY_AGENT").all()
#     return jsonify([
#         {"id": a.id, "name": f"{a.first_name} {a.last_name}", "phone_no": a.phone_no}
#         for a in agents
#     ]), 200


# # ─── 5. DELIVERY AGENT ASSIGNS A DRIVER ─────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/assign-driver", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def assign_driver(order_id):

#     order = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if order.status not in ("ASSIGNED_TO_AGENT", "ASSIGNED_TO_DRIVER"):
#         return jsonify({"error": "Order must be assigned to a delivery agent first"}), 400

#     # A delivery agent may only act on orders assigned to them.
#     if current_user.role == "DELIVERY_AGENT" and order.delivery_agent_id != current_user.id:
#         return jsonify({"error": "This order is not assigned to you"}), 403

#     data = request.get_json()
#     driver_id = data.get("driver_id")

#     if not driver_id:
#         return jsonify({"error": "driver_id is required"}), 400

#     driver = User.query.get(driver_id)
#     if not driver:
#         return jsonify({"error": "Driver not found"}), 404
#     if driver.role != "DRIVER":
#         return jsonify({"error": "Selected user is not a driver"}), 400

#     old_status = order.status

#     order.driver_id = driver.id
#     order.driver_assigned_by = current_user.id
#     order.driver_assigned_at = datetime.utcnow()
#     order.driver_accepted_at = None
#     order.status = "ASSIGNED_TO_DRIVER"

#     log_order_status(
#         order, old_status, "ASSIGNED_TO_DRIVER", current_user.id,
#         f"Driver {driver.first_name} {driver.last_name} assigned by "
#         f"{current_user.first_name} {current_user.last_name}"
#     )

#     db.session.commit()

#     notify_admins(
#         f"Order {order.order_number}: delivery agent assigned driver "
#         f"{driver.first_name} {driver.last_name}",
#         order
#     )

#     return jsonify({
#         "message": "Driver assigned successfully",
#         "order": order.to_dict()
#     }), 200


# # ─── 6. DRIVER ACCEPTS THE ORDER ────────────────────────────────────────────

# # @order_bp.route("/orders/<int:order_id>/driver-accept", methods=["POST"])
# # @jwt_required()
# # @role_required(["DRIVER"])
# # def driver_accept(order_id):

# #     order = Order.query.get_or_404(order_id)
# #     current_user = get_current_user()

# #     if order.driver_id != current_user.id:
# #         return jsonify({"error": "Order not assigned to you"}), 403

# #     if order.status != "ASSIGNED_TO_DRIVER":
# #         return jsonify({"error": "Order is not awaiting driver acceptance"}), 400

# #     old_status = order.status
# #     now = datetime.utcnow()

# #     order.driver_accepted_at = now
# #     order.status = "DRIVER_ACCEPTED"

# #     log_order_status(order, old_status, "DRIVER_ACCEPTED", current_user.id)
# #     db.session.commit()

# #     # Immediately move into OUT_FOR_DELIVERY so the driver can start the trip.
# #     order.out_for_delivery_at = now
# #     order.status = "OUT_FOR_DELIVERY"
# #     log_order_status(order, "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY", current_user.id)
# #     db.session.commit()

# #     if order.delivery_agent_id:
# #         notify_admins(
# #             f"Order {order.order_number} accepted by driver "
# #             f"{current_user.first_name} {current_user.last_name} and is now out for delivery",
# #             order
# #         )

# #     return jsonify({
# #         "message": "Delivery accepted, order is out for delivery",
# #         "order": order.to_dict()
# #     }), 200


# # @order_bp.route("/orders/<int:order_id>/driver-reject", methods=["POST"])
# # @jwt_required()
# # @role_required(["DRIVER"])
# # def driver_reject(order_id):
# #     order = Order.query.get_or_404(order_id)
# #     current_user = get_current_user()

# #     if order.driver_id != current_user.id:
# #         return jsonify({"error": "Order not assigned to you"}), 403

# #     old_status = order.status

# #     order.driver_id = None
# #     order.driver_assigned_by = None
# #     order.driver_assigned_at = None
# #     order.driver_accepted_at = None
# #     order.status = "ASSIGNED_TO_AGENT"  # bounces back to the delivery agent

# #     log_order_status(order, old_status, "ASSIGNED_TO_AGENT", current_user.id, "Rejected by driver")
# #     db.session.commit()

# #     notify_admins(f"Driver rejected order {order.order_number}; returned to delivery agent", order)

# #     return jsonify({"message": "Order rejected, returned to delivery agent", "order": order.to_dict()}), 200


# # ─── 7. DRIVER SUBMITS DELIVERY PROOF (photo) TO DELIVERY AGENT ─────────────

# # @order_bp.route("/orders/<int:order_id>/delivery-proof", methods=["POST"])
# # @jwt_required()
# # @role_required(["DRIVER"])
# # def upload_delivery_proof(order_id):

# #     order = Order.query.get_or_404(order_id)
# #     current_user = get_current_user()

# #     if order.driver_id != current_user.id:
# #         return jsonify({"error": "Order not assigned to you"}), 403

# #     if order.status != "OUT_FOR_DELIVERY":
# #         return jsonify({"error": "Order is not out for delivery"}), 400

# #     data = request.get_json()

# #     order.delivery_photo = data.get("delivery_photo")
# #     order.delivery_notes = data.get("delivery_notes") or data.get("notes")
# #     order.customer_confirmation_name = data.get("customer_confirmation_name") or data.get("customer_name")
# #     order.customer_confirmation_phone = data.get("customer_confirmation_phone") or data.get("customer_phone")

# #     old_status = order.status
# #     order.driver_submitted_at = datetime.utcnow()
# #     order.status = "DELIVERY_SUBMITTED"

# #     log_order_status(order, old_status, "DELIVERY_SUBMITTED", current_user.id, "Driver submitted delivery proof")

# #     db.session.commit()

# #     notify_admins(
# #         f"Order {order.order_number}: driver submitted delivery proof, "
# #         f"awaiting delivery agent confirmation",
# #         order
# #     )

# #     return jsonify({
# #         "message": "Delivery proof submitted to delivery agent",
# #         "order": order.to_dict()
# #     }), 200


# # ─── 8. DELIVERY AGENT CONFIRMS FINAL DELIVERY ──────────────────────────────

# # @order_bp.route("/orders/<int:order_id>/confirm-delivery", methods=["POST"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# # def confirm_delivery(order_id):

# #     order = Order.query.get_or_404(order_id)
# #     current_user = get_current_user()

# #     if current_user.role == "DELIVERY_AGENT" and order.delivery_agent_id != current_user.id:
# #         return jsonify({"error": "This order is not assigned to you"}), 403

# #     if order.status != "DELIVERY_SUBMITTED":
# #         return jsonify({"error": "Delivery proof not yet submitted by driver"}), 400

# #     old_status = order.status
# #     now = datetime.utcnow()

# #     order.status = "DELIVERED"
# #     order.delivered_at = now
# #     order.delivery_confirmed_by = current_user.id
# #     order.delivery_confirmed_at = now

# #     log_order_status(order, old_status, "DELIVERED", current_user.id, "Confirmed by delivery agent")

# #     db.session.commit()

# #     notify_admins(
# #         f"Order {order.order_number} DELIVERED — confirmed by "
# #         f"{current_user.first_name} {current_user.last_name}",
# #         order
# #     )

# #     return jsonify({
# #         "message": "Delivery confirmed",
# #         "order": order.to_dict()
# #     }), 200


# # ─── ROLE-SCOPED "MY ORDERS" LISTS ──────────────────────────────────────────

# @order_bp.route("/orders/kitchen/my-orders", methods=["GET"])
# @jwt_required()
# @role_required(["KITCHEN_STAFF"])
# def get_my_kitchen_orders():
#     current_user = get_current_user()
#     orders = Order.query.filter(
#         Order.kitchen_staff_id == current_user.id,
#         Order.status.in_(["ASSIGNED_TO_KITCHEN", "PREPARING"])
#     ).order_by(Order.created_at.desc()).all()

#     return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/agent/my-orders", methods=["GET"])
# @jwt_required()
# @role_required(["DELIVERY_AGENT"])
# def get_my_agent_orders():
#     current_user = get_current_user()
#     orders = Order.query.filter(
#         Order.delivery_agent_id == current_user.id,
#         Order.status.in_([
#             "ASSIGNED_TO_AGENT", "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
#             "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"
#         ])
#     ).order_by(Order.created_at.desc()).all()

#     return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/driver/my-orders", methods=["GET"])
# @jwt_required()
# @role_required(["DRIVER"])
# def get_my_driver_orders():
#     current_user = get_current_user()
#     orders = Order.query.filter(
#         Order.driver_id == current_user.id,
#         Order.status.in_(["ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"])
#     ).order_by(Order.created_at.desc()).all()

#     return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/kitchen/<int:kitchen_staff_id>", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def get_kitchen_assigned_orders(kitchen_staff_id):
#     orders = Order.query.filter_by(kitchen_staff_id=kitchen_staff_id).order_by(Order.created_at.desc()).all()
#     return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/agent/<int:agent_id>", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def get_agent_assigned_orders(agent_id):
#     orders = Order.query.filter_by(delivery_agent_id=agent_id).order_by(Order.created_at.desc()).all()
#     return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/driver/<int:driver_id>", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def get_driver_assigned_orders(driver_id):
#     orders = Order.query.filter_by(driver_id=driver_id).order_by(Order.created_at.desc()).all()
#     return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/status/<string:status>", methods=["GET"])
# @jwt_required()
# def orders_by_status(status):
#     orders = Order.query.filter_by(status=status.upper()).order_by(Order.created_at.desc()).all()
#     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# # @order_bp.route("/orders/customer/<int:customer_id>", methods=["GET"])
# # @jwt_required()
# # @role_required(["ADMIN", "SHOP_MANAGER", "SALES_AGENT", "USER"])
# # def orders_by_customer(customer_id):
# #     orders = Order.query.filter_by(user_id=customer_id).order_by(Order.created_at.desc()).all()
# #     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/customer/<int:customer_id>", methods=["GET"])
# @jwt_required()
# def orders_by_customer(customer_id):

#     current_user = get_current_user()

#     # Admins can see any customer's orders
#     if current_user.role in ["ADMIN", "SHOP_MANAGER", "SALES_AGENT"]:
#         pass

#     # Users can only see their own orders
#     elif current_user.role == "USER":
#         if current_user.id != customer_id:
#             return jsonify({"error": "Forbidden"}), 403

#     else:
#         return jsonify({"error": "Forbidden"}), 403

#     orders = (
#         Order.query
#         .filter_by(user_id=customer_id)
#         .order_by(Order.created_at.desc())
#         .all()
#     )

#     return jsonify({
#         "orders": [o.to_dict() for o in orders]
#     }), 200



# @order_bp.route("/orders/created-by/<int:agent_id>", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def orders_by_creator(agent_id):
#     orders = Order.query.filter_by(created_by=agent_id).order_by(Order.created_at.desc()).all()
#     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/<int:order_id>/history", methods=["GET"])
# @jwt_required()
# def order_history(order_id):
#     from models.order_status_history import OrderStatusHistory
#     history = OrderStatusHistory.query.filter_by(order_id=order_id).order_by(
#         OrderStatusHistory.created_at.desc()
#     ).all()
#     return jsonify({"history": [h.to_dict() for h in history]}), 200


# # ─── IMAGES ──────────────────────────────────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/upload-image", methods=["POST"])
# @jwt_required()
# def upload_order_image(order_id):
#     import cloudinary.uploader
#     order = Order.query.get_or_404(order_id)
#     file = request.files.get("image")
#     if not file:
#         return jsonify({"error": "No image provided"}), 400
#     result = cloudinary.uploader.upload(file, folder=f"orders/{order_id}")
#     images = order.delivery_images or []
#     images.append({"url": result["secure_url"], "public_id": result["public_id"]})
#     order.delivery_images = images
#     db.session.commit()
#     return jsonify({"message": "Image uploaded", "image_url": result["secure_url"]}), 200


# @order_bp.route("/orders/<int:order_id>/images", methods=["GET"])
# @jwt_required()
# def get_order_images(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({"images": order.delivery_images or []}), 200


# @order_bp.route("/orders/<int:order_id>/images/<string:image_id>", methods=["DELETE"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER"])
# def delete_order_image(order_id, image_id):
#     order = Order.query.get_or_404(order_id)
#     order.delivery_images = [
#         img for img in (order.delivery_images or [])
#         if img.get("public_id") != image_id
#     ]
#     db.session.commit()
#     return jsonify({"message": "Image deleted"}), 200


# # ─── GREETING CARD ───────────────────────────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/greeting", methods=["POST"])
# @jwt_required()
# def add_greeting(order_id):
#     order = Order.query.get_or_404(order_id)
#     data = request.get_json()
#     order.greeting_message = data.get("message")
#     order.greeting_from = data.get("from")
#     order.greeting_to = data.get("to")
#     db.session.commit()
#     return jsonify({"message": "Greeting added", "order": order.to_dict()}), 201


# @order_bp.route("/orders/<int:order_id>/greeting", methods=["PUT"])
# @jwt_required()
# def update_greeting(order_id):
#     order = Order.query.get_or_404(order_id)
#     data = request.get_json()
#     if "message" in data:
#         order.greeting_message = data["message"]
#     if "from" in data:
#         order.greeting_from = data["from"]
#     if "to" in data:
#         order.greeting_to = data["to"]
#     db.session.commit()
#     return jsonify({"message": "Greeting updated", "order": order.to_dict()}), 200


# @order_bp.route("/orders/<int:order_id>/greeting", methods=["GET"])
# @jwt_required()
# def get_greeting(order_id):
#     order = Order.query.get_or_404(order_id)
#     return jsonify({
#         "message": order.greeting_message,
#         "from": order.greeting_from,
#         "to": order.greeting_to
#     }), 200



# # ─────────────────────────────────────────────────────────────────────────────
# # PATCH — replace these 3 functions inside routes/order_routes.py
# #
# # Changes vs existing code:
# #  driver_accept     → sets current_user.availability_status = "BUSY"
# #  driver_reject     → sets current_user.availability_status = "ONLINE"
# #  confirm_delivery  → sets driver.availability_status = "ONLINE"
# #
# # Everything else in order_routes.py stays the same.
# # ─────────────────────────────────────────────────────────────────────────────


# # ─── 6. DRIVER ACCEPTS THE ORDER ────────────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/driver-accept", methods=["POST"])
# @jwt_required()
# @role_required(["DRIVER"])
# def driver_accept(order_id):

#     order        = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if order.driver_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     if order.status != "ASSIGNED_TO_DRIVER":
#         return jsonify({"error": "Order is not awaiting driver acceptance"}), 400

#     old_status = order.status
#     now        = datetime.utcnow()

#     order.driver_accepted_at = now
#     order.status             = "DRIVER_ACCEPTED"
#     log_order_status(order, old_status, "DRIVER_ACCEPTED", current_user.id)

#     # Immediately move to OUT_FOR_DELIVERY so the driver can start the trip
#     order.out_for_delivery_at = now
#     order.status              = "OUT_FOR_DELIVERY"
#     log_order_status(order, "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY", current_user.id)

#     # ── FIX: mark driver BUSY so they don't appear in available-drivers list ──
#     current_user.availability_status = "BUSY"

#     db.session.commit()

#     notify_admins(
#         f"Order {order.order_number} accepted by driver "
#         f"{current_user.first_name} {current_user.last_name} — now out for delivery",
#         order,
#     )

#     return jsonify({
#         "message": "Delivery accepted, order is out for delivery",
#         "order": order.to_dict(),
#     }), 200


# # ─── 6b. DRIVER REJECTS THE ORDER ───────────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/driver-reject", methods=["POST"])
# @jwt_required()
# @role_required(["DRIVER"])
# def driver_reject(order_id):

#     order        = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if order.driver_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     old_status = order.status

#     order.driver_id          = None
#     order.driver_assigned_by = None
#     order.driver_assigned_at = None
#     order.driver_accepted_at = None
#     order.status             = "ASSIGNED_TO_AGENT"   # bounce back to delivery agent

#     # ── FIX: driver is free again ─────────────────────────────────────────────
#     current_user.availability_status = "ONLINE"

#     log_order_status(
#         order, old_status, "ASSIGNED_TO_AGENT",
#         current_user.id, "Rejected by driver"
#     )
#     db.session.commit()

#     notify_admins(
#         f"Driver rejected order {order.order_number}; returned to delivery agent",
#         order,
#     )

#     return jsonify({
#         "message": "Order rejected, returned to delivery agent",
#         "order": order.to_dict(),
#     }), 200


# # ─── 7. DRIVER SUBMITS DELIVERY PROOF ───────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/delivery-proof", methods=["POST"])
# @jwt_required()
# @role_required(["DRIVER"])
# def upload_delivery_proof(order_id):

#     order        = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if order.driver_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     if order.status != "OUT_FOR_DELIVERY":
#         return jsonify({"error": "Order is not out for delivery"}), 400

#     data = request.get_json() or {}

#     order.delivery_photo               = data.get("delivery_photo")
#     order.delivery_notes               = data.get("delivery_notes") or data.get("notes")
#     order.customer_confirmation_name   = (
#         data.get("customer_confirmation_name") or data.get("customer_name")
#     )
#     order.customer_confirmation_phone  = (
#         data.get("customer_confirmation_phone") or data.get("customer_phone")
#     )

#     old_status              = order.status
#     order.driver_submitted_at = datetime.utcnow()
#     order.status            = "DELIVERY_SUBMITTED"

#     log_order_status(
#         order, old_status, "DELIVERY_SUBMITTED",
#         current_user.id, "Driver submitted delivery proof"
#     )
#     db.session.commit()

#     notify_admins(
#         f"Order {order.order_number}: driver submitted proof — "
#         f"awaiting delivery agent confirmation",
#         order,
#     )

#     return jsonify({
#         "message": "Delivery proof submitted to delivery agent",
#         "order": order.to_dict(),
#     }), 200


# # ─── 8. DELIVERY AGENT CONFIRMS FINAL DELIVERY ──────────────────────────────

# @order_bp.route("/orders/<int:order_id>/confirm-delivery", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def confirm_delivery(order_id):

#     order        = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if current_user.role == "DELIVERY_AGENT" and order.delivery_agent_id != current_user.id:
#         return jsonify({"error": "This order is not assigned to you"}), 403

#     if order.status != "DELIVERY_SUBMITTED":
#         return jsonify({"error": "Delivery proof not yet submitted by driver"}), 400

#     old_status = order.status
#     now        = datetime.utcnow()

#     order.status               = "DELIVERED"
#     order.delivered_at         = now
#     order.delivery_confirmed_by = current_user.id
#     order.delivery_confirmed_at = now

#     # ── FIX: driver is free — mark them ONLINE again ──────────────────────────
#     if order.driver_id:
#         driver = User.query.get(order.driver_id)
#         if driver:
#             driver.availability_status = "ONLINE"

#     log_order_status(
#         order, old_status, "DELIVERED",
#         current_user.id, "Confirmed by delivery agent"
#     )
#     db.session.commit()

#     notify_admins(
#         f"Order {order.order_number} DELIVERED — confirmed by "
#         f"{current_user.first_name} {current_user.last_name}",
#         order,
#     )

#     return jsonify({
#         "message": "Delivery confirmed",
#         "order": order.to_dict(),
#     }), 200


import stripe
import random
from datetime import datetime

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from extensions import db
from config import Config

from models.order import Order
from models.order_item import OrderItem
from models.product import Product
from models.user import User
from models.address import Address

from middleware.n8n_auth import n8n_key_required
from services.point_service import add_points
from services.notification_service import send_order_notification
from middleware.role import role_required
from services.order_history_service import log_order_status


order_bp = Blueprint("order", __name__)

stripe.api_key = Config.STRIPE_SECRET_KEY


# ─── UTILS ─────────────────────────────────────────────────────────────────

def get_current_user():
    user_id = get_jwt_identity()
    return User.query.get(int(user_id))


def generate_order_number():
    return f"CT-{datetime.now().strftime('%Y%m%d')}-{random.randint(1000,9999)}"


def build_n8n_payload(order):
    return {
        "body": {
            "order": {
                "orderId": order.id,
                "total": float(order.total),
                "items": [
                    {
                        "name": item.product.name,
                        "quantity": item.quantity,
                        "price": float(item.price)
                    } for item in order.items
                ]
            },
            "customer": {
                "name": f"{order.customer.first_name} {order.customer.last_name}",
                "email": order.customer.email,
                "phone": order.customer.phone_no
            },
            "admin": {
                "email": "orders@caketake.com",
                "phone": "9198778945"
            }
        }
    }

def notify_admins(message, order=None):
    """Best-effort notification to admin / shop manager. Never raises."""
    try:
        send_order_notification({
            "message": message,
            "order_id": order.id if order else None,
            "order_number": order.order_number if order else None,
        })
    except Exception as e:
        print("Notification error:", str(e))


def _normalize_phone(phone: str) -> str:
    return "".join(ch for ch in (phone or "") if ch.isdigit())[-10:]


def _status_to_customer_message(status: str) -> str:
    messages = {
        "PENDING": "Your order has been received and is awaiting confirmation.",
        "ACCEPTED": "Your order has been confirmed.",
        "ASSIGNED_TO_KITCHEN": "Your order is queued for preparation.",
        "PREPARING": "Your order is being prepared.",
        "READY": "Your order is ready and awaiting dispatch.",
        "ASSIGNED_TO_AGENT": "Your order is being arranged for delivery.",
        "ASSIGNED_TO_DRIVER": "A driver has been assigned to your order.",
        "OUT_FOR_DELIVERY": "Your order is out for delivery.",
        "DELIVERY_SUBMITTED": "Your delivery is being confirmed.",
        "DELIVERED": "Your order has been delivered.",
        "REJECTED": "Your order was not accepted.",
        "CANCELLED": "Your order was cancelled.",
    }
    return messages.get(status, "We're processing your order.")


# ─── CREATE ORDER ────────────────────────────────────────────────────────────

@order_bp.route("/orders", methods=["POST"])
@jwt_required()
def create_order():

    user = get_current_user()
    data = request.get_json()

    if not data:
        return jsonify({"error": "No data provided"}), 400

    required_fields = ["address_id", "items"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"{field} is required"}), 400

    address = Address.query.get(data["address_id"])
    if not address:
        return jsonify({"error": "Address not found"}), 404

    items_data = data["items"]
    if not items_data:
        return jsonify({"error": "Order must contain at least one item"}), 400

    payment_method = (data.get("payment_method") or "COD").upper()

    order = Order(
        user_id=user.id,
        created_by=user.id,
        order_number=generate_order_number(),
        order_type=data.get("order_type", "direct_order"),
        address_id=address.id,
        delivery_date=datetime.strptime(
            data["delivery_date"], "%Y-%m-%d"
        ).date() if data.get("delivery_date") else None,
        delivery_time_slot=data.get("delivery_time_slot"),
        payment_method=payment_method,
        payment_status="PENDING",
        status="PENDING",
        total=0
    )

    db.session.add(order)
    db.session.flush()

    total_amount = 0

    for item in items_data:

        product = Product.query.get(item["product_id"])
        if not product:
            return jsonify({"error": f"Product {item['product_id']} not found"}), 404

        quantity = item.get("quantity", 1)

        item_total = float(product.price) * quantity
        total_amount += item_total

        order_item = OrderItem(
            order_id=order.id,
            product_id=product.id,
            quantity=quantity,
            price=product.price,
            line_total=item_total,
            custom_json=item.get("custom_json")
        )

        db.session.add(order_item)

    delivery_charge = float(data.get("delivery_charge", 0))
    discount = float(data.get("discount", 0))
    grand_total = total_amount + delivery_charge - discount

    order.subtotal = total_amount
    order.delivery_charge = delivery_charge
    order.discount = discount
    order.grand_total = grand_total
    order.loyalty_coupon = data.get("loyalty_coupon")
    order.currency = data.get("currency", "INR")
    order.total = grand_total

    try:
        add_points(user.phone_no, total_amount)
    except Exception as e:
        print("Loyalty points error:", str(e))

    db.session.commit()

    try:
        send_order_notification(build_n8n_payload(order))
    except Exception as e:
        print("Notification Error:", str(e))

    return jsonify({
        "message": "Order created successfully",
        "order": order.to_dict()
    }), 201


# ─── GET ALL ORDERS (ROLE BASED) ────────────────────────────────────────────

@order_bp.route("/orders", methods=["GET"])
@jwt_required()
def get_orders():

    user = get_current_user()
    status = request.args.get("status")

    query = Order.query

    if user.role == "USER":
        query = query.filter_by(user_id=user.id)

    elif user.role == "KITCHEN_STAFF":
        query = query.filter(
            Order.kitchen_staff_id == user.id,
            Order.status.in_(["ASSIGNED_TO_KITCHEN", "PREPARING"])
        )

    elif user.role == "DELIVERY_AGENT":
        query = query.filter(
            db.or_(
                Order.delivery_agent_id == user.id,
                Order.status == "ASSIGNED_TO_AGENT"
            )
        )

    elif user.role == "DRIVER":
        query = query.filter(Order.driver_id == user.id)

    elif user.role in ("ADMIN", "SHOP_MANAGER", "SALES_AGENT"):
        pass  # full access

    if status:
        query = query.filter_by(status=status.upper())

    orders = query.order_by(Order.created_at.desc()).all()

    return jsonify({
        "count": len(orders),
        "orders": [o.to_dict() for o in orders]
    }), 200


# ─── GET SINGLE ORDER ────────────────────────────────────────────────────────

@order_bp.route("/orders/<int:id>", methods=["GET"])
@jwt_required()
def get_order(id):

    order = Order.query.get(id)

    if not order:
        return jsonify({"error": "Order not found"}), 404

    return jsonify(order.to_dict()), 200


# ─── UPDATE ORDER (ADMIN / SHOP MANAGER) ────────────────────────────────────

@order_bp.route("/orders/<int:id>", methods=["PUT"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def update_order(id):

    order = Order.query.get(id)
    if not order:
        return jsonify({"error": "Order not found"}), 404

    data = request.get_json()

    order.status = data.get("status", order.status)
    order.payment_status = data.get("payment_status", order.payment_status)

    db.session.commit()

    return jsonify({
        "message": "Order updated successfully",
        "order": order.to_dict()
    }), 200


# ─── DELETE ORDER (ADMIN) ────────────────────────────────────────────────────

@order_bp.route("/orders/<int:id>", methods=["DELETE"])
@jwt_required()
@role_required(["ADMIN"])
def delete_order(id):

    order = Order.query.get(id)

    if not order:
        return jsonify({"error": "Order not found"}), 404

    db.session.delete(order)
    db.session.commit()

    return jsonify({"message": "Order deleted successfully"}), 200


# ─── STRIPE CHECKOUT (kept for card payments) ───────────────────────────────

@order_bp.route("/create-checkout-session", methods=["POST"])
@jwt_required()
def create_checkout_session():

    data = request.get_json()
    amount = int(float(data["amount"]) * 100)

    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        line_items=[{
            "price_data": {
                "currency": "inr",
                "product_data": {"name": "Bakery Order"},
                "unit_amount": amount
            },
            "quantity": 1
        }],
        mode="payment",
        success_url="http://localhost:3000/payment-success?session_id={CHECKOUT_SESSION_ID}",
        cancel_url="http://localhost:3000/payment-cancel"
    )

    return jsonify({
        "session_id": session.id,
        "url": session.url
    }), 200


# ─── USER ORDERS ─────────────────────────────────────────────────────────────

@order_bp.route("/orders/user/<int:user_id>", methods=["GET"])
@jwt_required()
def get_user_orders(user_id):

    orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()

    return jsonify({
        "count": len(orders),
        "orders": [o.to_dict() for o in orders]
    }), 200


# ══════════════════════════════════════════════════════════════════════════
#  WORKFLOW: accept -> kitchen -> ready -> agent -> driver -> delivered
# ══════════════════════════════════════════════════════════════════════════

# ─── 1. ACCEPT ORDER (sets payment_status from COD / UPI) ──────────────────

@order_bp.route("/orders/<int:id>/accept", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def accept_order(id):

    order = Order.query.get_or_404(id)

    if order.status != "PENDING":
        return jsonify({"error": "Only pending orders can be accepted"}), 400

    old_status = order.status
    current_user = get_current_user()

    data = request.get_json(silent=True) or {}

    # Payment method can be confirmed/overridden at accept time, otherwise
    # whatever was set at order creation is used.
    payment_method = (data.get("payment_method") or order.payment_method or "COD").upper()
    order.payment_method = payment_method

    if payment_method == "COD":
        order.payment_status = "PENDING"
    elif payment_method == "UPI":
        order.payment_status = "COMPLETED"
    # any other method (CARD/STRIPE) is left as-is; those flows set
    # payment_status themselves via /payments/* routes.

    order.status = "ACCEPTED"

    log_order_status(
        order,
        old_status,
        "ACCEPTED",
        current_user.id,
        f"Order accepted. Payment method: {payment_method}, payment_status: {order.payment_status}"
    )

    db.session.commit()

    notify_admins(f"Order {order.order_number} accepted ({payment_method})", order)

    return jsonify({
        "message": "Order accepted",
        "order": order.to_dict()
    }), 200


@order_bp.route("/orders/<int:order_id>/reject", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def reject_order(order_id):

    order = Order.query.get_or_404(order_id)
    data = request.get_json() or {}

    if order.status != "PENDING":
        return jsonify({"error": "Only pending orders can be rejected"}), 400

    old_status = order.status
    order.status = "REJECTED"
    order.rejection_reason = data.get("reason")

    log_order_status(order, old_status, "REJECTED", get_current_user().id, data.get("reason"))

    db.session.commit()

    return jsonify({
        "message": "Order rejected",
        "order": order.to_dict()
    }), 200


@order_bp.route("/orders/<int:order_id>/cancel", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "SALES_AGENT"])
def cancel_order(order_id):
    order = Order.query.get_or_404(order_id)
    if order.status in ("DELIVERED", "CANCELLED"):
        return jsonify({"error": f"Cannot cancel an order that is {order.status}"}), 400

    data = request.get_json() or {}
    old_status = order.status
    order.status = "CANCELLED"
    order.rejection_reason = data.get("reason")

    log_order_status(order, old_status, "CANCELLED", get_current_user().id, data.get("reason"))

    db.session.commit()
    return jsonify({"message": "Order cancelled", "order": order.to_dict()}), 200


# ─── 2. ASSIGN TO KITCHEN ────────────────────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/assign-kitchen", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def assign_kitchen(order_id):

    order = Order.query.get_or_404(order_id)

    if order.status != "ACCEPTED":
        return jsonify({"error": "Order must be ACCEPTED before assigning to kitchen"}), 400

    data = request.get_json()
    kitchen_staff_id = data.get("kitchen_staff_id")

    kitchen_staff = User.query.get(kitchen_staff_id)
    if not kitchen_staff:
        return jsonify({"error": "Kitchen staff not found"}), 404
    if kitchen_staff.role != "KITCHEN_STAFF":
        return jsonify({"error": "Selected user is not kitchen staff"}), 400

    old_status = order.status

    order.kitchen_staff_id = kitchen_staff.id
    order.kitchen_assigned_by = get_current_user().id
    order.kitchen_assigned_at = datetime.utcnow()
    order.status = "ASSIGNED_TO_KITCHEN"

    log_order_status(order, old_status, "ASSIGNED_TO_KITCHEN", get_current_user().id)

    db.session.commit()

    return jsonify({
        "message": "Kitchen assigned",
        "order": order.to_dict()
    }), 200


@order_bp.route("/orders/<int:order_id>/reassign-kitchen", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def reassign_kitchen(order_id):
    order = Order.query.get_or_404(order_id)
    data = request.get_json()

    staff = User.query.filter_by(id=data.get("kitchen_staff_id"), role="KITCHEN_STAFF").first()
    if not staff:
        return jsonify({"error": "Kitchen staff not found"}), 404

    order.kitchen_staff_id = staff.id
    order.kitchen_assigned_by = get_current_user().id
    order.kitchen_assigned_at = datetime.utcnow()

    db.session.commit()
    return jsonify({"message": "Kitchen staff reassigned", "order": order.to_dict()}), 200


@order_bp.route("/kitchen-staff", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def get_kitchen_staff():
    staff = User.query.filter_by(role="KITCHEN_STAFF").all()
    return jsonify([
        {"id": s.id, "name": f"{s.first_name} {s.last_name}"}
        for s in staff
    ]), 200


# ─── 3. KITCHEN: PREPARING -> READY ─────────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/start-preparation", methods=["POST"])
@jwt_required()
@role_required(["KITCHEN_STAFF", "ADMIN", "SHOP_MANAGER"])
def start_preparation(order_id):

    order = Order.query.get_or_404(order_id)
    current_user = get_current_user()

    if current_user.role == "KITCHEN_STAFF" and order.kitchen_staff_id != current_user.id:
        return jsonify({"error": "Order not assigned to you"}), 403

    if order.status != "ASSIGNED_TO_KITCHEN":
        return jsonify({"error": "Order must be ASSIGNED_TO_KITCHEN to start preparation"}), 400

    old_status = order.status
    order.status = "PREPARING"
    order.preparation_started_at = datetime.utcnow()

    log_order_status(order, old_status, "PREPARING", current_user.id)

    db.session.commit()

    return jsonify({
        "message": "Preparation started",
        "order": order.to_dict()
    }), 200


@order_bp.route("/orders/<int:order_id>/ready", methods=["POST"])
@jwt_required()
@role_required(["KITCHEN_STAFF", "ADMIN", "SHOP_MANAGER"])
def mark_ready(order_id):

    order = Order.query.get_or_404(order_id)
    current_user = get_current_user()

    if current_user.role == "KITCHEN_STAFF" and order.kitchen_staff_id != current_user.id:
        return jsonify({"error": "Order not assigned to you"}), 403

    if order.status != "PREPARING":
        return jsonify({"error": "Order must be PREPARING before it can be marked READY"}), 400

    old_status = order.status
    order.status = "READY"
    order.completed_by_kitchen_at = datetime.utcnow()

    log_order_status(order, old_status, "READY", current_user.id)

    db.session.commit()

    notify_admins(f"Order {order.order_number} is READY for dispatch", order)

    return jsonify({
        "message": "Order marked READY",
        "order": order.to_dict()
    }), 200


# ─── 4. ASSIGN TO DELIVERY AGENT (owner/shop manager -> DELIVERY_AGENT) ─────

@order_bp.route("/orders/<int:order_id>/assign-agent", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def assign_delivery_agent(order_id):

    order = Order.query.get_or_404(order_id)

    if order.status != "READY":
        return jsonify({"error": "Order must be READY before assigning a delivery agent"}), 400

    data = request.get_json()
    agent_id = data.get("delivery_agent_id") or data.get("agent_id")

    if not agent_id:
        return jsonify({"error": "delivery_agent_id is required"}), 400

    agent = User.query.get(agent_id)
    if not agent:
        return jsonify({"error": "Delivery agent not found"}), 404
    if agent.role != "DELIVERY_AGENT":
        return jsonify({"error": "Selected user is not a delivery agent"}), 400

    old_status = order.status
    current_user = get_current_user()

    order.delivery_agent_id = agent.id
    order.delivery_agent_assigned_by = current_user.id
    order.delivery_agent_assigned_at = datetime.utcnow()
    order.status = "ASSIGNED_TO_AGENT"

    log_order_status(
        order, old_status, "ASSIGNED_TO_AGENT", current_user.id,
        f"Assigned to delivery agent {agent.first_name} {agent.last_name}"
    )

    db.session.commit()

    notify_admins(
        f"Order {order.order_number} assigned to delivery agent "
        f"{agent.first_name} {agent.last_name}",
        order
    )

    return jsonify({
        "message": "Delivery agent assigned",
        "order": order.to_dict()
    }), 200


@order_bp.route("/orders/<int:order_id>/reassign-agent", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def reassign_delivery_agent(order_id):
    order = Order.query.get_or_404(order_id)
    data = request.get_json()

    agent = User.query.filter_by(
        id=data.get("delivery_agent_id"), role="DELIVERY_AGENT"
    ).first()
    if not agent:
        return jsonify({"error": "Delivery agent not found"}), 404

    order.delivery_agent_id = agent.id
    order.delivery_agent_assigned_by = get_current_user().id
    order.delivery_agent_assigned_at = datetime.utcnow()

    # Reassigning the agent also clears any driver previously picked by the
    # old agent, since the new agent should choose their own driver.
    order.driver_id = None
    order.driver_assigned_by = None
    order.driver_assigned_at = None
    order.driver_accepted_at = None
    if order.status in ("ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY"):
        order.status = "ASSIGNED_TO_AGENT"

    db.session.commit()
    return jsonify({"message": "Delivery agent reassigned", "order": order.to_dict()}), 200


@order_bp.route("/delivery-agents", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def get_delivery_agents():
    agents = User.query.filter_by(role="DELIVERY_AGENT").all()
    return jsonify([
        {"id": a.id, "name": f"{a.first_name} {a.last_name}", "phone_no": a.phone_no}
        for a in agents
    ]), 200


# ─── 5. DELIVERY AGENT ASSIGNS A DRIVER ─────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/assign-driver", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def assign_driver(order_id):

    order = Order.query.get_or_404(order_id)
    current_user = get_current_user()

    if order.status not in ("ASSIGNED_TO_AGENT", "ASSIGNED_TO_DRIVER"):
        return jsonify({"error": "Order must be assigned to a delivery agent first"}), 400

    # A delivery agent may only act on orders assigned to them.
    if current_user.role == "DELIVERY_AGENT" and order.delivery_agent_id != current_user.id:
        return jsonify({"error": "This order is not assigned to you"}), 403

    data = request.get_json()
    driver_id = data.get("driver_id")

    if not driver_id:
        return jsonify({"error": "driver_id is required"}), 400

    driver = User.query.get(driver_id)
    if not driver:
        return jsonify({"error": "Driver not found"}), 404
    if driver.role != "DRIVER":
        return jsonify({"error": "Selected user is not a driver"}), 400

    old_status = order.status

    order.driver_id = driver.id
    order.driver_assigned_by = current_user.id
    order.driver_assigned_at = datetime.utcnow()
    order.driver_accepted_at = None
    order.status = "ASSIGNED_TO_DRIVER"

    log_order_status(
        order, old_status, "ASSIGNED_TO_DRIVER", current_user.id,
        f"Driver {driver.first_name} {driver.last_name} assigned by "
        f"{current_user.first_name} {current_user.last_name}"
    )

    db.session.commit()

    notify_admins(
        f"Order {order.order_number}: delivery agent assigned driver "
        f"{driver.first_name} {driver.last_name}",
        order
    )

    return jsonify({
        "message": "Driver assigned successfully",
        "order": order.to_dict()
    }), 200


# ─── 6. DRIVER ACCEPTS THE ORDER ────────────────────────────────────────────

# @order_bp.route("/orders/<int:order_id>/driver-accept", methods=["POST"])
# @jwt_required()
# @role_required(["DRIVER"])
# def driver_accept(order_id):

#     order = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if order.driver_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     if order.status != "ASSIGNED_TO_DRIVER":
#         return jsonify({"error": "Order is not awaiting driver acceptance"}), 400

#     old_status = order.status
#     now = datetime.utcnow()

#     order.driver_accepted_at = now
#     order.status = "DRIVER_ACCEPTED"

#     log_order_status(order, old_status, "DRIVER_ACCEPTED", current_user.id)
#     db.session.commit()

#     # Immediately move into OUT_FOR_DELIVERY so the driver can start the trip.
#     order.out_for_delivery_at = now
#     order.status = "OUT_FOR_DELIVERY"
#     log_order_status(order, "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY", current_user.id)
#     db.session.commit()

#     if order.delivery_agent_id:
#         notify_admins(
#             f"Order {order.order_number} accepted by driver "
#             f"{current_user.first_name} {current_user.last_name} and is now out for delivery",
#             order
#         )

#     return jsonify({
#         "message": "Delivery accepted, order is out for delivery",
#         "order": order.to_dict()
#     }), 200


# @order_bp.route("/orders/<int:order_id>/driver-reject", methods=["POST"])
# @jwt_required()
# @role_required(["DRIVER"])
# def driver_reject(order_id):
#     order = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if order.driver_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     old_status = order.status

#     order.driver_id = None
#     order.driver_assigned_by = None
#     order.driver_assigned_at = None
#     order.driver_accepted_at = None
#     order.status = "ASSIGNED_TO_AGENT"  # bounces back to the delivery agent

#     log_order_status(order, old_status, "ASSIGNED_TO_AGENT", current_user.id, "Rejected by driver")
#     db.session.commit()

#     notify_admins(f"Driver rejected order {order.order_number}; returned to delivery agent", order)

#     return jsonify({"message": "Order rejected, returned to delivery agent", "order": order.to_dict()}), 200


# ─── 7. DRIVER SUBMITS DELIVERY PROOF (photo) TO DELIVERY AGENT ─────────────

# @order_bp.route("/orders/<int:order_id>/delivery-proof", methods=["POST"])
# @jwt_required()
# @role_required(["DRIVER"])
# def upload_delivery_proof(order_id):

#     order = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if order.driver_id != current_user.id:
#         return jsonify({"error": "Order not assigned to you"}), 403

#     if order.status != "OUT_FOR_DELIVERY":
#         return jsonify({"error": "Order is not out for delivery"}), 400

#     data = request.get_json()

#     order.delivery_photo = data.get("delivery_photo")
#     order.delivery_notes = data.get("delivery_notes") or data.get("notes")
#     order.customer_confirmation_name = data.get("customer_confirmation_name") or data.get("customer_name")
#     order.customer_confirmation_phone = data.get("customer_confirmation_phone") or data.get("customer_phone")

#     old_status = order.status
#     order.driver_submitted_at = datetime.utcnow()
#     order.status = "DELIVERY_SUBMITTED"

#     log_order_status(order, old_status, "DELIVERY_SUBMITTED", current_user.id, "Driver submitted delivery proof")

#     db.session.commit()

#     notify_admins(
#         f"Order {order.order_number}: driver submitted delivery proof, "
#         f"awaiting delivery agent confirmation",
#         order
#     )

#     return jsonify({
#         "message": "Delivery proof submitted to delivery agent",
#         "order": order.to_dict()
#     }), 200


# ─── 8. DELIVERY AGENT CONFIRMS FINAL DELIVERY ──────────────────────────────

# @order_bp.route("/orders/<int:order_id>/confirm-delivery", methods=["POST"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
# def confirm_delivery(order_id):

#     order = Order.query.get_or_404(order_id)
#     current_user = get_current_user()

#     if current_user.role == "DELIVERY_AGENT" and order.delivery_agent_id != current_user.id:
#         return jsonify({"error": "This order is not assigned to you"}), 403

#     if order.status != "DELIVERY_SUBMITTED":
#         return jsonify({"error": "Delivery proof not yet submitted by driver"}), 400

#     old_status = order.status
#     now = datetime.utcnow()

#     order.status = "DELIVERED"
#     order.delivered_at = now
#     order.delivery_confirmed_by = current_user.id
#     order.delivery_confirmed_at = now

#     log_order_status(order, old_status, "DELIVERED", current_user.id, "Confirmed by delivery agent")

#     db.session.commit()

#     notify_admins(
#         f"Order {order.order_number} DELIVERED — confirmed by "
#         f"{current_user.first_name} {current_user.last_name}",
#         order
#     )

#     return jsonify({
#         "message": "Delivery confirmed",
#         "order": order.to_dict()
#     }), 200


# ─── ROLE-SCOPED "MY ORDERS" LISTS ──────────────────────────────────────────

@order_bp.route("/orders/kitchen/my-orders", methods=["GET"])
@jwt_required()
@role_required(["KITCHEN_STAFF"])
def get_my_kitchen_orders():
    current_user = get_current_user()
    orders = Order.query.filter(
        Order.kitchen_staff_id == current_user.id,
        Order.status.in_(["ASSIGNED_TO_KITCHEN", "PREPARING"])
    ).order_by(Order.created_at.desc()).all()

    return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/agent/my-orders", methods=["GET"])
@jwt_required()
@role_required(["DELIVERY_AGENT"])
def get_my_agent_orders():
    current_user = get_current_user()
    orders = Order.query.filter(
        Order.delivery_agent_id == current_user.id,
        Order.status.in_([
            "ASSIGNED_TO_AGENT", "ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED",
            "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"
        ])
    ).order_by(Order.created_at.desc()).all()

    return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/driver/my-orders", methods=["GET"])
@jwt_required()
@role_required(["DRIVER"])
def get_my_driver_orders():
    current_user = get_current_user()
    orders = Order.query.filter(
        Order.driver_id == current_user.id,
        Order.status.in_(["ASSIGNED_TO_DRIVER", "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY", "DELIVERY_SUBMITTED"])
    ).order_by(Order.created_at.desc()).all()

    return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/kitchen/<int:kitchen_staff_id>", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def get_kitchen_assigned_orders(kitchen_staff_id):
    orders = Order.query.filter_by(kitchen_staff_id=kitchen_staff_id).order_by(Order.created_at.desc()).all()
    return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/agent/<int:agent_id>", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def get_agent_assigned_orders(agent_id):
    orders = Order.query.filter_by(delivery_agent_id=agent_id).order_by(Order.created_at.desc()).all()
    return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/driver/<int:driver_id>", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def get_driver_assigned_orders(driver_id):
    orders = Order.query.filter_by(driver_id=driver_id).order_by(Order.created_at.desc()).all()
    return jsonify({"count": len(orders), "orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/status/<string:status>", methods=["GET"])
@jwt_required()
def orders_by_status(status):
    orders = Order.query.filter_by(status=status.upper()).order_by(Order.created_at.desc()).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


# @order_bp.route("/orders/customer/<int:customer_id>", methods=["GET"])
# @jwt_required()
# @role_required(["ADMIN", "SHOP_MANAGER", "SALES_AGENT", "USER"])
# def orders_by_customer(customer_id):
#     orders = Order.query.filter_by(user_id=customer_id).order_by(Order.created_at.desc()).all()
#     return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/customer/<int:customer_id>", methods=["GET"])
@jwt_required()
def orders_by_customer(customer_id):

    current_user = get_current_user()

    # Admins, shop managers and sales agents can view any customer's orders
    if current_user.role in ["ADMIN", "SHOP_MANAGER", "SALES_AGENT","USER"]:
        pass

    # Normal users can only view their own orders
    # elif current_user.role == "USER":
    #     if current_user.id != customer_id:
    #         return jsonify({
    #             "error": "Forbidden"
    #         }), 403

    else:
        return jsonify({
            "error": "Forbidden"
        }), 403

    orders = Order.query.filter_by(user_id=customer_id)\
        .order_by(Order.created_at.desc()).all()

    return jsonify({
        "orders": [o.to_dict() for o in orders]
    }), 200

@order_bp.route("/orders/created-by/<int:agent_id>", methods=["GET"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def orders_by_creator(agent_id):
    orders = Order.query.filter_by(created_by=agent_id).order_by(Order.created_at.desc()).all()
    return jsonify({"orders": [o.to_dict() for o in orders]}), 200


@order_bp.route("/orders/<int:order_id>/history", methods=["GET"])
@jwt_required()
def order_history(order_id):
    from models.order_status_history import OrderStatusHistory
    history = OrderStatusHistory.query.filter_by(order_id=order_id).order_by(
        OrderStatusHistory.created_at.desc()
    ).all()
    return jsonify({"history": [h.to_dict() for h in history]}), 200


# ─── IMAGES ──────────────────────────────────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/upload-image", methods=["POST"])
@jwt_required()
def upload_order_image(order_id):
    import cloudinary.uploader
    order = Order.query.get_or_404(order_id)
    file = request.files.get("image")
    if not file:
        return jsonify({"error": "No image provided"}), 400
    result = cloudinary.uploader.upload(file, folder=f"orders/{order_id}")
    images = order.delivery_images or []
    images.append({"url": result["secure_url"], "public_id": result["public_id"]})
    order.delivery_images = images
    db.session.commit()
    return jsonify({"message": "Image uploaded", "image_url": result["secure_url"]}), 200


@order_bp.route("/orders/<int:order_id>/images", methods=["GET"])
@jwt_required()
def get_order_images(order_id):
    order = Order.query.get_or_404(order_id)
    return jsonify({"images": order.delivery_images or []}), 200


@order_bp.route("/orders/<int:order_id>/images/<string:image_id>", methods=["DELETE"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER"])
def delete_order_image(order_id, image_id):
    order = Order.query.get_or_404(order_id)
    order.delivery_images = [
        img for img in (order.delivery_images or [])
        if img.get("public_id") != image_id
    ]
    db.session.commit()
    return jsonify({"message": "Image deleted"}), 200


# ─── GREETING CARD ───────────────────────────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/greeting", methods=["POST"])
@jwt_required()
def add_greeting(order_id):
    order = Order.query.get_or_404(order_id)
    data = request.get_json()
    order.greeting_message = data.get("message")
    order.greeting_from = data.get("from")
    order.greeting_to = data.get("to")
    db.session.commit()
    return jsonify({"message": "Greeting added", "order": order.to_dict()}), 201


@order_bp.route("/orders/<int:order_id>/greeting", methods=["PUT"])
@jwt_required()
def update_greeting(order_id):
    order = Order.query.get_or_404(order_id)
    data = request.get_json()
    if "message" in data:
        order.greeting_message = data["message"]
    if "from" in data:
        order.greeting_from = data["from"]
    if "to" in data:
        order.greeting_to = data["to"]
    db.session.commit()
    return jsonify({"message": "Greeting updated", "order": order.to_dict()}), 200


@order_bp.route("/orders/<int:order_id>/greeting", methods=["GET"])
@jwt_required()
def get_greeting(order_id):
    order = Order.query.get_or_404(order_id)
    return jsonify({
        "message": order.greeting_message,
        "from": order.greeting_from,
        "to": order.greeting_to
    }), 200


# ─── N8N CHATBOT ENDPOINTS (service-to-service, not user JWT) ───────────────

@order_bp.route("/chatbot/orders/track", methods=["GET"])
@n8n_key_required
def chatbot_track_order():
    order_number = request.args.get("order_number")
    phone = request.args.get("phone")

    if not order_number or not phone:
        return jsonify({"error": "order_number and phone are required"}), 400

    order = Order.query.filter_by(order_number=order_number).first()

    if not order or _normalize_phone(order.customer.phone_no) != _normalize_phone(phone):
        return jsonify({"error": "No matching order found"}), 404

    return jsonify({
        "order_number": order.order_number,
        "status": order.status,
        "payment_status": order.payment_status,
        "total": float(order.total) if order.total is not None else None,
        "delivery_date": order.delivery_date.isoformat() if order.delivery_date else None,
        "delivery_time_slot": order.delivery_time_slot,
        "eta_notes": _status_to_customer_message(order.status),
    }), 200


@order_bp.route("/chatbot/orders/latest", methods=["GET"])
@n8n_key_required
def chatbot_latest_order():
    phone = request.args.get("phone")
    if not phone:
        return jsonify({"error": "phone is required"}), 400

    order = (
        Order.query.join(Order.customer)
        .filter(Order.customer.has(phone_no=phone))
        .order_by(Order.created_at.desc())
        .first()
    )

    if not order:
        return jsonify({"error": "No orders found for this phone number"}), 404

    return jsonify({
        "order_number": order.order_number,
        "status": order.status,
        "eta_notes": _status_to_customer_message(order.status),
    }), 200


# ─────────────────────────────────────────────────────────────────────────────
# PATCH — replace these 3 functions inside routes/order_routes.py
#
# Changes vs existing code:
#  driver_accept     → sets current_user.availability_status = "BUSY"
#  driver_reject     → sets current_user.availability_status = "ONLINE"
#  confirm_delivery  → sets driver.availability_status = "ONLINE"
#
# Everything else in order_routes.py stays the same.
# ─────────────────────────────────────────────────────────────────────────────


# ─── 6. DRIVER ACCEPTS THE ORDER ────────────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/driver-accept", methods=["POST"])
@jwt_required()
@role_required(["DRIVER"])
def driver_accept(order_id):

    order        = Order.query.get_or_404(order_id)
    current_user = get_current_user()

    if order.driver_id != current_user.id:
        return jsonify({"error": "Order not assigned to you"}), 403

    if order.status != "ASSIGNED_TO_DRIVER":
        return jsonify({"error": "Order is not awaiting driver acceptance"}), 400

    old_status = order.status
    now        = datetime.utcnow()

    order.driver_accepted_at = now
    order.status             = "DRIVER_ACCEPTED"
    log_order_status(order, old_status, "DRIVER_ACCEPTED", current_user.id)

    # Immediately move to OUT_FOR_DELIVERY so the driver can start the trip
    order.out_for_delivery_at = now
    order.status              = "OUT_FOR_DELIVERY"
    log_order_status(order, "DRIVER_ACCEPTED", "OUT_FOR_DELIVERY", current_user.id)

    # ── FIX: mark driver BUSY so they don't appear in available-drivers list ──
    current_user.availability_status = "BUSY"

    db.session.commit()

    notify_admins(
        f"Order {order.order_number} accepted by driver "
        f"{current_user.first_name} {current_user.last_name} — now out for delivery",
        order,
    )

    return jsonify({
        "message": "Delivery accepted, order is out for delivery",
        "order": order.to_dict(),
    }), 200


# ─── 6b. DRIVER REJECTS THE ORDER ───────────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/driver-reject", methods=["POST"])
@jwt_required()
@role_required(["DRIVER"])
def driver_reject(order_id):

    order        = Order.query.get_or_404(order_id)
    current_user = get_current_user()

    if order.driver_id != current_user.id:
        return jsonify({"error": "Order not assigned to you"}), 403

    old_status = order.status

    order.driver_id          = None
    order.driver_assigned_by = None
    order.driver_assigned_at = None
    order.driver_accepted_at = None
    order.status             = "ASSIGNED_TO_AGENT"   # bounce back to delivery agent

    # ── FIX: driver is free again ─────────────────────────────────────────────
    current_user.availability_status = "ONLINE"

    log_order_status(
        order, old_status, "ASSIGNED_TO_AGENT",
        current_user.id, "Rejected by driver"
    )
    db.session.commit()

    notify_admins(
        f"Driver rejected order {order.order_number}; returned to delivery agent",
        order,
    )

    return jsonify({
        "message": "Order rejected, returned to delivery agent",
        "order": order.to_dict(),
    }), 200


# ─── 7. DRIVER SUBMITS DELIVERY PROOF ───────────────────────────────────────

@order_bp.route("/orders/<int:order_id>/delivery-proof", methods=["POST"])
@jwt_required()
@role_required(["DRIVER"])
def upload_delivery_proof(order_id):

    order        = Order.query.get_or_404(order_id)
    current_user = get_current_user()

    if order.driver_id != current_user.id:
        return jsonify({"error": "Order not assigned to you"}), 403

    if order.status != "OUT_FOR_DELIVERY":
        return jsonify({"error": "Order is not out for delivery"}), 400

    data = request.get_json() or {}

    order.delivery_photo               = data.get("delivery_photo")
    order.delivery_notes               = data.get("delivery_notes") or data.get("notes")
    order.customer_confirmation_name   = (
        data.get("customer_confirmation_name") or data.get("customer_name")
    )
    order.customer_confirmation_phone  = (
        data.get("customer_confirmation_phone") or data.get("customer_phone")
    )

    old_status              = order.status
    order.driver_submitted_at = datetime.utcnow()
    order.status            = "DELIVERY_SUBMITTED"

    log_order_status(
        order, old_status, "DELIVERY_SUBMITTED",
        current_user.id, "Driver submitted delivery proof"
    )
    db.session.commit()

    notify_admins(
        f"Order {order.order_number}: driver submitted proof — "
        f"awaiting delivery agent confirmation",
        order,
    )

    return jsonify({
        "message": "Delivery proof submitted to delivery agent",
        "order": order.to_dict(),
    }), 200


# ─── 8. DELIVERY AGENT CONFIRMS FINAL DELIVERY ──────────────────────────────

@order_bp.route("/orders/<int:order_id>/confirm-delivery", methods=["POST"])
@jwt_required()
@role_required(["ADMIN", "SHOP_MANAGER", "DELIVERY_AGENT"])
def confirm_delivery(order_id):

    order        = Order.query.get_or_404(order_id)
    current_user = get_current_user()

    if current_user.role == "DELIVERY_AGENT" and order.delivery_agent_id != current_user.id:
        return jsonify({"error": "This order is not assigned to you"}), 403

    if order.status != "DELIVERY_SUBMITTED":
        return jsonify({"error": "Delivery proof not yet submitted by driver"}), 400

    old_status = order.status
    now        = datetime.utcnow()

    order.status               = "DELIVERED"
    order.delivered_at         = now
    order.delivery_confirmed_by = current_user.id
    order.delivery_confirmed_at = now

    # ── FIX: driver is free — mark them ONLINE again ──────────────────────────
    if order.driver_id:
        driver = User.query.get(order.driver_id)
        if driver:
            driver.availability_status = "ONLINE"

    log_order_status(
        order, old_status, "DELIVERED",
        current_user.id, "Confirmed by delivery agent"
    )
    db.session.commit()

    notify_admins(
        f"Order {order.order_number} DELIVERED — confirmed by "
        f"{current_user.first_name} {current_user.last_name}",
        order,
    )

    return jsonify({
        "message": "Delivery confirmed",
        "order": order.to_dict(),
    }), 200